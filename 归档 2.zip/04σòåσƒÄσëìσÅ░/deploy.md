# 部署

<img src="/deploy/images/01部署架构简图.png" style="zoom:35%">
