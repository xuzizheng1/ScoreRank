## SPU表管理

在SPU表中我们需要对SKU表数据进行增删改查操作，这时候我们可以借助于视图集中的**ModelViewset**来完成相应的操作

![sku](../../src/spu.png)

