# Nginx 实例
```
worker_processes  1;
events {
    worker_connections  1024;
}
http {
    include       mime.types;
    default_type  application/octet-stream;
    sendfile        on;
    keepalive_timeout  65;
    
	server {
		listen 81;
		server_name 81;
		location /{
			root /home/python/Desktop/81;
			index index.html;
		}
	}

	server {
		listen 82;
		server_name 82;
		location /{
			root /home/python/Desktop/82;
			index index.html;
		}
	}

	server {
		listen 83;
		server_name 83;
		location /{
			root /home/python/Desktop/83;
			index index.html;
		}
	}

	upstream meiduo{
		ip_hash;
		server 127.0.0.1:81 weight=1;
		server 127.0.0.1:82 weight=2;
		server 127.0.0.1:83 weight=3;
	}

	server {
		listen 80;
		server_name 80;
		location /{
			proxy_pass http://meiduo;
		}
	}
}

```
