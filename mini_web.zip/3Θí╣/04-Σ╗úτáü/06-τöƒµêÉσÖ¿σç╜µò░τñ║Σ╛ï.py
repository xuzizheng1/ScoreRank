

def Fib(n):
    a = 0
    b = 1
    current = 0
    while current < n:
        ret = a
        a, b = b, a+b
        yield ret  # 临时返回 a 值 给 for  不能使用 return 因为 return 就会导致整个代码 over
        # return ret
        current += 1

for i in Fib(10):
    print(i)