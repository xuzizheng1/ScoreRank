class Cat(object):
    def __init__(self,name,age):
        self.name = name
        self.age = age
    def get_age(self):
        return self.age
    def set_age(self, newage):
        if newage > 20:
            print("你设置的年龄要成精了  错误")
        else:
            self.age = newage

if __name__ == '__main__':
    tom = Cat("tom",18)
    # 对象.方法()       安全
    tom.set_age(1000)
    print(tom.get_age())

    # 对象.属性   直接  不安全
    # tom.age = 1000
    # print(tom.age)