
# 1 列表推导式
l1 = [i for i in range(10)]
print(type(l1), l1.__sizeof__())  # <class 'list'> 168

# 2 生成器generator 表达式
l2 = (i for i in range(10))
print(type(l2), l2.__sizeof__())   # <class 'generator'> 64

# 生成器对象可以使用 for 循环访问  不能使用下标  所以生成器并不能完全列表 各有所长
for i in l2:
    print(i)