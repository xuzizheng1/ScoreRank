import copy


a = (1, 2, 3)
b = a    # a 引用赋值给 b
print(id(a), id(b))  # 4326022096 4326022096

c = copy.copy(a)
print(id(a), id(c))  # 4326022096 4326022096

d = copy.deepcopy(a)
print(id(a), id(d))  # 4326022096 4326022096

# 不可变对象中全是不可变元素   深拷贝/浅拷贝一律都退化为引用赋值