import copy


a = [1, 2, 3, (4, 5)]
b = a    # a 引用赋值给 b   a 和 b 是同一个引用
print(id(a), id(b))  # 4427303368 4427303368

c = copy.copy(a)
print(id(a), id(c))        # 4427303368 4427303560
print(id(a[3]), id(c[3]))  # 4426700488 4426700488

d = copy.deepcopy(a)
print(id(a), id(d))        # 4427303368 4427304840
print(id(a[3]), id(d[3]))  # 4498417352 4498417352

# 含有不可变元素的 可变对象  浅拷贝-拷贝顶层结构; 深拷贝-拷贝顶层结构