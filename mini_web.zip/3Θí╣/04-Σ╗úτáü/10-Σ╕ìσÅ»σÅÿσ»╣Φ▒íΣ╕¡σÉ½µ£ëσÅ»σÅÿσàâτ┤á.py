import copy

a = (1, 2, 3, [4, 5])
b = a    # a 引用赋值给 b
print(id(a), id(b))  # 4346050264 4346050264

c = copy.copy(a)
print(id(a), id(c))        # 4346050264 4346050264
print(id(a[3]), id(c[3]))  # 4346616200  4346616200

d = copy.deepcopy(a)
print(id(a), id(d))       # 4346050264  4346270968
print(id(a[3]), id(d[3]))  # 4554815880 4554817352

# 含有可变元素的不可变对象  浅拷贝退化为引用赋值; 深拷贝则拷贝所有层次
