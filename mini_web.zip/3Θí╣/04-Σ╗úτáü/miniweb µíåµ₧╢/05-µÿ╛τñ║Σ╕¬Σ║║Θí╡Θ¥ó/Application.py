import json
import time

# 路由列表    路径　　　函数引用
# 增加了框架可维护性　　　app的代码不用做任何修改可以直接添加功能　　django框架添加路由方式
import pymysql

route_list = [
    # ('/gettime.html', get_time),
    # ('/index.html', index)
]

def app(path):
    def warpper(func):
        # 获取到路径及其对应的函数ｕ引用
        route_list.append((path, func))
        def inner():
            pass
        return inner
    return warpper

#  @app('路径')　将路径及其对应函数引用添加到路由列表中　　而非装饰作用  flask框架添加路由的方式
@app('/gettime.html')
def get_time():
    "视图函数　　　路由列表中　路径对应的函数"
    return time.ctime()

@app("/index.html")
def index():
    """当前用户请求/index.html　执行当前函数"""
    # １　将模板文件从磁盘读取到内存中
    with open("./template/index.html", encoding='utf-8') as file:
        html_data = file.read()
    # 2 从数据库中读取数据
    conn = pymysql.connect(host="localhost",port=3306,
                           user="root",
                           password="mysql",
                           database="stock_db",
                           charset="utf8")
    cur = conn.cursor()
    cur.execute("select * from info")
    data = cur.fetchall()
    cur.close()
    conn.close()

    # ３ 对模板文件进行替换《把占位符替换为用户需要的　　股票数据》
    # html_data = html_data.replace("{%content%}", "this is test data")
    stock_data = ""
    for line in data:
        # (1, '000007', '全新好', '10.01%', '4.40%', Decimal('16.05'), Decimal('14.60'), datetime.date(2017, 7, 18)
        line_str = '''<tr>
            <td>%s</td>
            <td>%s</td>
            <td>%s</td>
            <td>%s</td>
            <td>%s</td>
            <td>%s</td>
            <td>%s</td>
            <td>%s</td>
            <td><input type="button" value="添加" id="toAdd" name="toAdd" systemidvaule="000007"></td>
           </tr>''' % line
        stock_data += line_str
    html_data = html_data.replace("{%content%}", stock_data)
    # render_template('index.html', content="this is test data")
    return html_data


@app('/center.html')
def center():
    """提供网页　　不提供网页数据"""
    with open("./template/center.html", encoding='utf-8') as f:
        html_data = f.read()
    html_data = html_data.replace("{%content%}","")
    return html_data

@app('/center_data.html')
def center_data():
    # 1. 从数据库中读取数据
    sql = "select i.code,i.short,i.chg,i.turnover, i.price,i.highs, focus.note_info from info i inner join focus on i.id = focus.info_id"
    conn = pymysql.connect(host="localhost", port=3306,
                           user="root",
                           password="mysql",
                           database="stock_db",
                           charset="utf8")
    cur = conn.cursor()
    cur.execute(sql)
    data = cur.fetchall()
    cur.close()
    conn.close()
    # 2. 将用户转化为用户需要的JSON格式
    data_list = list()
    for row in data:
        center_dict = dict()
        center_dict["code"] = row[0]
        center_dict["short"] = row[1]
        center_dict["chg"] = row[2]
        center_dict["turnover"] = row[3]
        center_dict["price"] = str(row[4])
        center_dict["highs"] = str(row[5])
        center_dict["note_info"] = row[6]
        data_list.append(center_dict)

    # 3 将python到处为JSON字符串
    json_data = json.dumps(data_list, ensure_ascii=False)
    return json_data

def app(env):
    path_info = env['PATH_INFO']
    print("框架收到动态资源请求　%s" % path_info)

    for path,func in route_list:
        # 判断用户请求路径是否和某个路径一直　　如果一致就执行对应的函数
        if path_info == path:
            return "200 OK",[('Server', 'APP1.0')],func()
    # if path_info == '/gettime.html':
    #     return "200 OK",[('Server', 'APP1.0')],get_time()
    # elif path_info == '/index.html':
    #     return "200 OK", [('Server', 'APP1.0')],index()
    else:
        # 函数返回值就是给ｗｅｂ服务器的数据　　规定: 状态/头/体
        return "404 Not Found",[('Server', 'APP1.0')],"hello world"