import time


def get_time():
    return time.ctime()

def index():
    """当前用户请求/index.html　执行当前函数"""
    # １　将模板文件从磁盘读取到内存中
    with open("./template/index.html", encoding='utf-8') as file:
        html_data = file.read()

    # 2 对模板文件进行替换《把占位符替换为用户需要的数据》
    html_data = html_data.replace("{%content%}", "this is test data")

    # render_template('index.html', content="this is test data")
    return html_data

def app(env):
    path_info = env['PATH_INFO']
    print("框架收到动态资源请求　%s" % path_info)

    if path_info == '/gettime.html':
        return "200 OK",[('Server', 'APP1.0')],get_time()
    elif path_info == '/index.html':
        return "200 OK", [('Server', 'APP1.0')],index()
    else:
        # 函数返回值就是给ｗｅｂ服务器的数据　　规定: 状态/头/体
        return "200 OK",[('Server', 'APP1.0')],"hello world"