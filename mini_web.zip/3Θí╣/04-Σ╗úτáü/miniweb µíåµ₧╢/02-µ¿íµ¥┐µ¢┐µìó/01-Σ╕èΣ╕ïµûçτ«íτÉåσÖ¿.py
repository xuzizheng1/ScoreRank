#       __enter__方法为 with 提供资源  __exit__方法 为 with 关闭资源
import pymysql

class Connection(object):
    def __init__(self):
        self.conn = pymysql.connect(host="127.0.0.1",port=3306,user='root',
                                    password='mysql',db='py31',charset='utf8')

    def __enter__(self):
        """提供资源"""
        return self.conn

    def __exit__(self, exc_type, exc_val, exc_tb):
        """关闭资源"""
        print("执行到这里了")
        self.conn.close()   # 关闭资源

if __name__ == '__main__':
    with Connection() as conn:
        cur = conn.cursor()
        cur.execute("selectt * from students;")
        print(cur.fetchall())
        cur.close()