import socket
import threading
import time

# ｗｅｂ服务器＝TCP服务器＋HTTP协议<通过编写ｗｅｂ服务器养成编程思维　工作中不需要ｐｙｔｈｏｎ做 Nginx>
# 1.0 返回固定数据　总是返回　hello world
# 2.0 返回固定网页或者图片
import sys


class HTTPServer(object):
    def __init__(self, port):
        """初始化操作　创建属性"""
        # 1 创建一个服务器套接字　绑定　监听转接用户连接请求到　　和客户端关联的套接字
        server_socket = socket.socket()
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server_socket.bind(('', port))
        server_socket.listen(128)
        self.server_socket = server_socket

    def start(self):
        """启动ｗｅｂ服务器的工作"""
        while True:
            new_client_socket, client_address = self.server_socket.accept()
            print("客户端%s上线了" % str(client_address))
            # client_request(new_client_socket, client_address)
            # 每当有一个用户连接到服务器　启动一个线程或者协程运行对应的代码
            thd = threading.Thread(target=self.client_request, args=(new_client_socket, client_address))
            thd.daemon = True
            thd.start()

    @staticmethod
    def client_request(new_client_socket, client_address):
        # 2.接收用户请求报文< 一个套接字如果没有收数据就关了　那么可能报错>
        recv_data = new_client_socket.recv(4096)
        # print(recv_data)

        # 2.1 判断用户是否已经下线
        if not recv_data:
            print("客户端%s 已经下线了" % str(client_address))
            new_client_socket.close()
            return

        # 2.2 获取到用户请求报文中的资源路径
        # GET /xjj1.jpg HTTP/1.1\r\nHost: 127.0.0.1:9999\r\nConnection: keep-alive\r\nAccept: text/html,application/xhtml+xm
        path_info = recv_data.decode().split(" ")[1]
        print("收到用户的资源请求路径是,", path_info)  # /xjj1.jpg /getime.html

        # 2.3 判断如果用户请求路径是/  ------> ／ｉｎｄｅｘ.html
        if path_info == '/':
            path_info = "/grand.html"

        # 判断用户的资源请求　如果是静态资源请求就继续交给web服务器自己处理即可<往下>
        #                  如果是动态资源请求就交给框架处理
        if path_info.endswith(".html"):
            env = {
                "PATH_INFO": path_info
            }
            import Application
            # 接收状态,头,体　　　拼接成响应报文　给浏览器发回去
            status,headers,response_body = Application.app(env)
            response_data = "HTTP/1.1 %s\r\n" % status
            for header in headers:
                response_data += "%s: %s\r\n" % header

            response_data += "\r\n"
            response_data += response_body

            new_client_socket.send(response_data.encode())
            new_client_socket.close()

        else:
            # 2.4 打开一个指定的文件　　读取
            # with open("./static/index.html", "rb") as file:
            try:
                # 可能发生异常的代码
                with open("./static" + path_info, "rb") as file:
                    file_data = file.read()
            except Exception as e:
                # 如果发生异常　执行这里
                with open("./static/404.html", "rb") as file:
                    file_data = file.read()
                http_response_data = "HTTP/1.1 404 Not Found\r\nServer: PWS1.0\r\n\r\n".encode() + file_data
            else:
                # 没有异常执行这里
                # 3.回复响应报文<HTTP响应报文>
                http_response_data = "HTTP/1.1 200 OK\r\nServer: PWS1.0\r\n\r\n".encode() + file_data

            finally:
                # 不管有没有异常　都执行这里
                new_client_socket.send(http_response_data)
                time.sleep(2)
                # 4.关闭和客户端关联的套接字　　－　短连接
                new_client_socket.close()


def main():
    # print(sys.argv)   获取程序命令行参数列表　　每个元素都是字符串　xxx.py 8080
    if len(sys.argv) < 2:   # 判断参数个数
        print("你输入的参数有误　python3 web.py 8080")
        return
    # 判断参数２是否全是由数字构成的
    if not sys.argv[1].isdigit():
        print("你输入的参数有误　python3 web.py 8080")
        return

    port = int(sys.argv[1])

    # 调用类创建一个对象
    http_server = HTTPServer(port)   # __init__(self)
    http_server.start()

    # 实例方法self   ;类方法　cls @classmethod   ;静态方法@staticmethod


if __name__ == '__main__':
    # 浏览器中输入　　http://127.0.0.1:9999/haha.html
    main()
    # 面向对象<以类和对象方式考虑问题　适用性更高　抽象能力更好>　　   面向过程<动作功能>
    # 狗.吃(翔)　　　                                         吃(狗,翔)