import time


def get_time():
    return time.ctime()

def app(env):
    path_info = env['PATH_INFO']
    print("框架收到动态资源请求　%s" % path_info)

    if path_info == '/gettime.html':
        return "200 OK",[('Server', 'APP1.0')],get_time()
    else:
        # 函数返回值就是给ｗｅｂ服务器的数据　　规定: 状态/头/体
        return "200 OK",[('Server', 'APP1.0')],"hello world"