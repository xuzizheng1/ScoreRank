import copy


if __name__ == '__main__':
    tmp = [4,5]
    a1 = [1, 2, 3, tmp]
    a2 = copy.copy(a1)
    print(a1, a2)
    print(id(a1), id(a2))

    # 深拷贝
    a3 = copy.deepcopy(a1)
    a1[0] = 111
    a1[-1][-1] = 555

    print(a1, a3)
    print(id(a1), id(a3))