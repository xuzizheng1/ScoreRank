class Cat(object):
    def __init__(self, name, age):
        self._name = name
        self._age = age

    def get_age(self):
        """获取属性值的方法"""
        return self._age

    def set_age(self, newage):
        """设置属性值的方法"""
        if newage > 20:
            print("你设置的年龄要成精了  错误")
        else:
            self._age = newage
    # 定义 property        类属性 = property(获取属性方法,设置属性方法)
    age = property(get_age, set_age)

if __name__ == '__main__':
    tom = Cat("tom",18)
    # # 对象.方法()       安全
    # tom.set_age(1000)
    # print(tom.get_age())

    # 对象.属性   直接  不安全
    print(tom.age)
    tom.age = 1000
    print(tom.age)