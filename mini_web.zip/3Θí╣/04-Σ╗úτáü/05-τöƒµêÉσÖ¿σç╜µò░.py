def func():
    """生成器函数"""
    print("in func")
    # 1 挂起当前代码 将后面值返回到调用生成器代码的地方
    # 2 恢复代码从上次暂停的位置继续执行
    yield 1000
    print("-------------------")
    yield 1001
    yield 1002

# 生成器对象 = 生成器函数()
f = func()
print(type(f))   # <class 'generator'>

# 生成器函数调用方式 1  for i in 生成器对象:
# for i in f:
#     print(i)

# 2 下一个值 = next(生成器对象)
# print(next(f))
# print(next(f))
# print(next(f))
# print(next(f))   # StopIteration停止迭代  生成器执行完成自动抛出该异常

while True:
    try:
        i = next(f)
    except Exception as e:
        pass
    else:
        print(i)
