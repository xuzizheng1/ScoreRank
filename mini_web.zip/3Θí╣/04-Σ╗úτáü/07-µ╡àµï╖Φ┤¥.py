import copy


if __name__ == '__main__':
    tmp = [4,5]
    a1 = [1, 2, 3, tmp]
    # 浅拷贝   copy.copy 切片[:]  集合.copy()
    a2 = copy.copy(a1)

    a1[0] = 111
    a1[-1][-1] = 555

    print(a1, a2)
    print(id(a1), id(a2))