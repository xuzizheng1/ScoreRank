## 1. 知识回顾

## 2. Python 高级知识

### 2.1 property 属性

>   像使用属性一样    调用对象的方法  

-   装饰器方式

```python
class 类(object):
  	def __init__(self, x):
      	self._x = x
    @property
    def x(self):
      	return self._x
      
    @x.setter
    def x(self, newx):
      	# 判断
      	self._x = newx
      
对象 = 类()
对象.x
对象.x = 值
```



```python
class Cat(object):
    def __init__(self, name, age):
        self._name = name
        self._age = age

    @property
    def age(self):
        """获取属性值的方法"""
        return self._age

    @age.setter
    def age(self, newage):
        """设置属性值的方法"""
        if newage > 20:
            print("你设置的年龄要成精了  错误")
        else:
            self._age = newage

if __name__ == '__main__':
    tom = Cat("tom",18)
    # # 对象.方法()       安全
    # tom.set_age(1000)
    # print(tom.get_age())

    # 对象.属性   直接  不安全
    print(tom.age)
    tom.age = 1000
    print(tom.age)
```



-   类属性方式

```python
class 类(object):
  	def __init__(self, x):
      	self._x = x
    
    def get_x(self):
      	return self._x
      
    def set_x(self, newx):
      	# 判断
      	self._x = newx
    # 类属性
    x = property(get_x, set_x)
    
对象 = 类()
对象.x
对象.x = 值
```



```python
class Cat(object):
    def __init__(self, name, age):
        self._name = name
        self._age = age

    @property
    def age(self):
        """获取属性值的方法"""
        return self._age

    @age.setter
    def age(self, newage):
        """设置属性值的方法"""
        if newage > 20:
            print("你设置的年龄要成精了  错误")
        else:
            self._age = newage

if __name__ == '__main__':
    tom = Cat("tom",18)
    # # 对象.方法()       安全
    # tom.set_age(1000)
    # print(tom.get_age())

    # 对象.属性   直接  不安全
    print(tom.age)
    tom.age = 1000
    print(tom.age)class Cat(object):
    def __init__(self, name, age):
        self._name = name
        self._age = age

    def get_age(self):
        """获取属性值的方法"""
        return self._age

    def set_age(self, newage):
        """设置属性值的方法"""
        if newage > 20:
            print("你设置的年龄要成精了  错误")
        else:
            self._age = newage
    # 定义 property        类属性 = property(获取属性方法,设置属性方法)
    age = property(get_age, set_age)

if __name__ == '__main__':
    tom = Cat("tom",18)
    # # 对象.方法()       安全
    # tom.set_age(1000)
    # print(tom.get_age())

    # 对象.属性   直接  不安全
    print(tom.age)
    tom.age = 1000
    print(tom.age)
```





### 2.2 上下文管理器

with 作用:   自动资源管理

with open( ) as f:

​	f.read()

上下文管理器:   

​	给 with 语句`提供资源`并且  `提供关闭资源的方法`的   对象

常见上下文管理器:

​	文件/套接字/互斥锁/数据库连接

实现上下文管理器

```python
      __enter__方法为 with 提供资源
  		__exit__方法 为 with 关闭资源
```

```python
#       __enter__方法为 with 提供资源  __exit__方法 为 with 关闭资源
import pymysql

class Connection(object):
    def __init__(self):
        self.conn = pymysql.connect(host="127.0.0.1",port=3306,user='root',
                                    password='mysql',db='py31',charset='utf8')

    def __enter__(self):
        """提供资源"""
        return self.conn

    def __exit__(self, exc_type, exc_val, exc_tb):
        """关闭资源"""
        print("执行到这里了")
        self.conn.close()   # 关闭资源

if __name__ == '__main__':
    with Connection() as conn:
        cur = conn.cursor()
        cur.execute("selectt * from students;")
        print(cur.fetchall())
        cur.close()
```



>   exc_type, exc_val, exc_tb参数的意义   都和异常有关
>
>   如果没有异常  这三个参数为 None
>
>   异常 类型     值    跟踪信息

### 2.3 生成器

意义: 不保存数据  只是存储数据的生成规则  在用户需要的时候安装规则`生成`一个数据。

分类:    生成器表达式 和 生成器函数    

-   生成器表达式

```python
生成器对象 = (表达式)

for i in 生成器对象:
  	pass

# 1 列表推导式
l1 = [i for i in range(10)]
print(type(l1), l1.__sizeof__())  # <class 'list'> 168

# 2 生成器generator 表达式
l2 = (i for i in range(10))
print(type(l2), l2.__sizeof__())   # <class 'generator'> 64

# 生成器对象可以使用 for 循环访问  不能使用下标
for i in l2:
    print(i)
```

-   生成器函数

    含有 yield 关键字的函数

    生成器函数不再是普通函数《函数名()不会执行函数代码 是创建生成器对象》
    
    ```python
    def func():
        """生成器函数"""
        print("in func")
        # 1 挂起当前代码 将后面值返回到调用生成器代码的地方
        # 2 恢复代码从上次暂停的位置继续执行
        yield 1000
        print("-------------------")
        yield 1001
        yield 1002
    
    # 生成器对象 = 生成器函数()
    f = func()
    print(type(f))   # <class 'generator'>
    
    # 生成器函数调用方式 1  for i in 生成器对象:
    # for i in f:
    #     print(i)
    
    # 2 下一个值 = next(生成器对象)
    # print(next(f))
    # print(next(f))
    # print(next(f))
    # print(next(f))   # StopIteration停止迭代  生成器执行完成自动抛出该异常
    
    while True:
        try:
            i = next(f)
        except Exception as e:
            pass
        else:
            print(i)
    
    ```
    
    

```python


def Fib(n):
    a = 0
    b = 1
    current = 0
    while current < n:
        ret = a
        a, b = b, a+b
        yield ret  # 临时返回 a 值 给 for  不能使用 return 因为 return 就会导致整个代码 over
        # return ret
        current += 1

for i in Fib(10):
    print(i)
```



### 2.4 深/浅拷贝

>   面试必问

拷贝目的:  源数据进行独立

-   浅拷贝

![image-20200102114641153](day13 笔记.assets/image-20200102114641153.png)

-   深拷贝 

```python
import copy


if __name__ == '__main__':
    tmp = [4,5]
    a1 = [1, 2, 3, tmp]
    a2 = copy.copy(a1)
    print(a1, a2)
    print(id(a1), id(a2))

    # 深拷贝
    a3 = copy.deepcopy(a1)
    a1[0] = 111
    a1[-1][-1] = 555

    print(a1, a3)
    print(id(a1), id(a3))
```

-   全是不可变元素的不可变对象

```python
import copy


a = (1, 2, 3)
b = a    # a 引用赋值给 b
print(id(a), id(b))  # 4326022096 4326022096

c = copy.copy(a)
print(id(a), id(c))  # 4326022096 4326022096

d = copy.deepcopy(a)
print(id(a), id(d))  # 4326022096 4326022096

# 不可变对象中全是不可变元素   深拷贝/浅拷贝一律都退化为引用赋值
```

-   含有可变元素的不可变对象

    ```python
    import copy
    
    a = (1, 2, 3, [4, 5])
    b = a    # a 引用赋值给 b
    print(id(a), id(b))  # 4346050264 4346050264
    
    c = copy.copy(a)
    print(id(a), id(c))        # 4346050264 4346050264
    print(id(a[3]), id(c[3]))  # 4346616200  4346616200
    
    d = copy.deepcopy(a)
    print(id(a), id(d))       # 4346050264  4346270968
    print(id(a[3]), id(d[3]))  # 4554815880 4554817352
    
    # 含有可变元素的不可变对象  浅拷贝退化为引用赋值; 深拷贝则拷贝所有层次
    ```

- 含有不可变元素的可变对象

```python
import copy


a = [1, 2, 3, (4, 5)]
b = a    # a 引用赋值给 b   a 和 b 是同一个引用
print(id(a), id(b))  # 4427303368 4427303368

c = copy.copy(a)
print(id(a), id(c))        # 4427303368 4427303560
print(id(a[3]), id(c[3]))  # 4426700488 4426700488

d = copy.deepcopy(a)
print(id(a), id(d))        # 4427303368 4427304840
print(id(a[3]), id(d[3]))  # 4498417352 4498417352

# 含有不可变元素的 可变对象  浅拷贝-拷贝顶层结构; 深拷贝-拷贝顶层结构
```

​    



### 3. miniweb 框架

>   理解  路由
>
>   模板的作用
>
>   框架的运行流程



### 3.1 服务器-框架运行流程

![image-20200102122902644](day13 笔记.assets/image-20200102122902644.png)

