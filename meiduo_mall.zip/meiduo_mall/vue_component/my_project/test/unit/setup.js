import Vue from 'vue'

Vue.config.productionTip = false
