<template>
  <div>{{msg}}</div>
</template>

<script>
export default {
  name: "A",
  data() {
    return {
      msg: "BBBBBBBBB"
    };
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
div {
  height: 200px;
  background-color: paleturquoise;
  font-size: 40px;
}
</style>
