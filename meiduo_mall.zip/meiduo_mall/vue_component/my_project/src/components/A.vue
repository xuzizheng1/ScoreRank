<template>
  <div class="hello">
    {{msg}}
    <B />
  </div>
</template>

<script>
import B from "@/components/B";
export default {
  name: "A",
  data() {
    return {
      msg: "AAAAAAAAA"
    };
  },
  components: { B }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
div {
  height: 400px;
  background-color: burlywood;
  font-size: 40px;
}
</style>
