import json

from django.http import JsonResponse, HttpResponseNotFound
from django.views import View
from rest_framework.generics import GenericAPIView, ListCreateAPIView, RetrieveUpdateDestroyAPIView
from rest_framework.mixins import ListModelMixin, CreateModelMixin, DestroyModelMixin, UpdateModelMixin, \
    RetrieveModelMixin
from rest_framework.response import Response
from rest_framework.views import APIView

from .serializers import BookInfoSerializer, HeroInfoSerializer, QueryListModelMixin, MyModelViewSet
from .models import BookInfo, HeroInfo


# class BookInfoViewSet(ModelViewSet):
#     queryset = BookInfo.objects.all()
#     serializer_class = BookInfoSerializer


# class HeroInfoViewSet(ModelViewSet):
#     queryset = HeroInfo.objects.all()
#     serializer_class = HeroInfoSerializer


class BookInfoViewSet(MyModelViewSet):  # 如果只实现查询接口，可以继承ReadOnlyModelViewSet
    queryset = BookInfo.objects.all()
    serializer_class = BookInfoSerializer


class HerosView(GenericAPIView):
    """
    # 查询所有英雄-GET  增加一个英雄-POST
    url(r'^heros/$',views.HerosView.as_view()),

    图书模型类 BookInfo 的字段：
        hname = models.CharField(max_length=20, verbose_name='名称')
        hgender = models.SmallIntegerField(choices=GENDER_CHOICES, default=0, verbose_name='性别')
        hcomment = models.CharField(max_length=200, null=True, verbose_name='描述信息')
        hbook = models.ForeignKey(BookInfo, on_delete=models.CASCADE, verbose_name='图书')  # 外键
        is_delete = models.BooleanField(default=False, verbose_name='逻辑删除')
    """

    # 查询所有英雄
    def get(self, request):
        # 接收查询参数 keyword
        keyword = request.GET.get('keyword')
        query_set = HeroInfo.objects
        if keyword:
            # http://127.0.0.1:8000/heros?keyword=黄
            heros = query_set.filter(hname__contains=keyword)
        else:
            # http://127.0.0.1:8000/heros
            heros = query_set.all()

        # hero_list = []
        # for hero in heros:
        #     hero_list.append({
        #         'id': hero.id,
        #         'hname': hero.hname,
        #         'hgender': hero.hgender,
        #         'hcomment': hero.hcomment,
        #         # 注意：hero.hbook是BookInfo对象，不能序列化
        #         'hbook_id': hero.hbook.id,
        #         'hbook': hero.hbook.btitle,
        #     })

        ser = HeroInfoSerializer(instance=heros, many=True)

        return JsonResponse(data=ser.data, safe=False, status=200)

    # 增加一个英雄
    def post(self, request):
        # 获取请求体json数据，字节类型转换成字典
        json_dict = json.loads(request.body.decode())

        # 省略校验参数
        ser = HeroInfoSerializer(data=json_dict)
        ser.is_valid(raise_exception=True)
        ser.save()

        # hero = HeroInfo.objects.create(**json_dict)
        # hero_dict = {
        #     'id': hero.id,
        #     'hname': hero.hname,
        #     'hgender': hero.hgender,
        #     'hcomment': hero.hcomment,
        #     # 'hbook_id':hero.hbook.id,
        #     'hbook_id': hero.hbook_id,
        #     'hbook': hero.hbook.btitle,
        # }

        return JsonResponse(data=ser.data, status=201)


class HeroView(GenericAPIView):
    """
    # 根据主键查询一个英雄-GET  根据主键修改一个英雄-PUT  根据主键删除一个英雄-DELETE
    url(r'^heros/(?P<pk>\d+)/$',views.HeroView.as_view()),
    """

    # 根据主键查询一个英雄
    def get(self, request, pk):
        try:
            hero = HeroInfo.objects.get(pk=pk)
        except HeroInfo.DoesNotExist:
            return HttpResponseNotFound('英雄不存在')

        # hero_dict = {
        #     'id': hero.id,
        #     'hname': hero.hname,
        #     'hgender': hero.hgender,
        #     'hcomment': hero.hcomment,
        #     'hbook_id': hero.hbook_id,
        #     'hbook': hero.hbook.btitle,
        # }

        ser = HeroInfoSerializer(instance=hero)

        return JsonResponse(data=ser.data, status=200)

    # 根据主键修改一个英雄
    def put(self, request, pk):
        try:
            hero = HeroInfo.objects.get(pk=pk)
        except HeroInfo.DoesNotExist:
            return HttpResponseNotFound('英雄不存在')
        json_dict = json.loads(request.body.decode())

        # 省略校验参数

        # 修改并保存到数据库
        # hero.hname = json_dict.get('hname')
        # hero.hgender = json_dict.get('hgender')
        # hero.hcomment = json_dict.get('hcomment')
        # hero.hbook_id = json_dict.get('hbook_id')
        # hero.save()

        # 返回前端的数据
        # hero_dict = {
        #     'id': hero.id,
        #     'hname': hero.hname,
        #     'hgender': hero.hgender,
        #     'hcomment': hero.hcomment,
        #     'hbook_id': hero.hbook_id,
        #     'hbook': hero.hbook.btitle,
        # }

        ser = HeroInfoSerializer(instance=hero, data=json_dict)
        ser.is_valid(raise_exception=True)
        ser.save()

        return JsonResponse(data=ser.data, status=201)

    # 根据主键删除一个英雄
    def delete(self, request, pk):
        try:
            hero = HeroInfo.objects.get(pk=pk)
        except HeroInfo.DoesNotExist:
            return HttpResponseNotFound('英雄不存在')
        except Exception:
            return JsonResponse({'error': '删除失败'})
        else:
            hero.delete()
        return JsonResponse(data={'message': '删除成功'}, status=204)
