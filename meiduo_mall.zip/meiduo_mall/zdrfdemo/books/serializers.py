from rest_framework import serializers, mixins
from rest_framework.mixins import ListModelMixin
from rest_framework.response import Response
from rest_framework.viewsets import GenericViewSet

from books.models import BookInfo, HeroInfo


def has_py(value):
    if 'py' not in value.lower():
        raise serializers.ValidationError('图书名必须包含py..')
    return value


# # 定义图书类的序列化器，自定义 校验
# class BookInfoSerializer(serializers.Serializer):
#     """
#     验证的方式：
#         1。字段类型
#             IntegerField
#             CharField
#         2。约束参数
#             max_length
#             read_only
#             required
#         3。自定义校验
#             validate_<field_name>
#             validate
#             validators
#     """
#     id = serializers.IntegerField(read_only=True)
#     # 自定义校验 3。字段中的选项参数 validators
#     btitle = serializers.CharField(min_length=3, max_length=10,
#                                    error_messages={'max_length': '书名不得大于10个字符。。'}, validators=[has_py])
#     bpub_date = serializers.DateField(required=False)
#     bread = serializers.IntegerField(default=0)
#     bcomment = serializers.IntegerField(default=0)
#     is_delete = serializers.BooleanField(default=0)
#
#     # 自定义校验 1。单字段 validate_字段名()
#     def validate_btitle(self, value):
#         if 'it' not in value.lower():
#             raise serializers.ValidationError('图书名必须包含it..')
#         return value
#
#     # 自定义校验 2。多字段 validate()
#     def validate(self, attrs):
#         bread = attrs['bread']
#         bcomment = attrs['bcomment']
#         if all([bread, bcomment]):
#             if bread < bcomment:
#                 raise serializers.ValidationError('评论量不能大于阅读量。。')
#         return attrs
#
#     # 增加功能
#     def create(self, validated_data):
#         return BookInfo.objects.create(**validated_data)
#
#     # 修改功能
#     def update(self, instance, validated_data):
#         """更新，instance为要更新的对象实例"""
#         instance.btitle = validated_data.get('btitle', instance.btitle)
#         instance.bpub_date = validated_data.get('bpub_date', instance.bpub_date)
#         instance.bread = validated_data.get('bread', instance.bread)
#         instance.bcomment = validated_data.get('bcomment', instance.bcomment)
#         instance.save()
#         return instance


# # 模型类的序列化器的定义方法
class BookInfoSerializer(serializers.ModelSerializer):
    """图书数据序列化器"""

    # 类属性 -- ModelSerializer 'all'所有字段 不包含隐藏字段
    heroinfo_set = serializers.StringRelatedField(read_only=True, many=True)

    # 自定义校验 1。单字段 validate_字段名()
    def validate_btitle(self, value):
        if 'it' not in value.lower():
            raise serializers.ValidationError('图书名必须包含it..')
        return value

    # 自定义校验 2。多字段 validate()
    def validate(self, attrs):
        bread = attrs.get('bread')
        bcomment = attrs.get('bcomment')
        if all([bread, bcomment]):
            if bread < bcomment:
                raise serializers.ValidationError('评论量不能大于阅读量。。')
        return attrs

    class Meta:
        model = BookInfo

        # 1.指明所有字段
        fields = '__all__'

        # 1) 或者 指明 部分字段
        # fields = ('id', 'btitle', 'bpub_date')

        # 2) 使用**exclude**可以明确排除掉哪些字段;exclude和fields只能使用一个
        # exclude = ('image',)
        # 3)  指明只读字段--可以通过**read_only_fields**指明只读字段，即仅用于序列化输出的字段
        read_only_fields = ('id', 'bread', 'bcomment')

        # 使用extra_kwargs参数为ModelSerializer添加或修改原有的选项参数
        # 自定义校验 3。字段中的选项参数 validators
        extra_kwargs = {
            'btitle': {'min_length': 3, 'max_length': 10, 'validators': [has_py]},
        }


#
#
class HeroInfoSerializer(serializers.ModelSerializer):
    """英雄数据序列化器"""

    class Meta:
        model = HeroInfo
        fields = '__all__'

        read_only_fields = ('id',)


# class HeroInfoSerializer(serializers.Serializer):
#     id = serializers.IntegerField(read_only=True)
#     hname = serializers.CharField(max_length=5)
#     hgender = serializers.IntegerField(required=False, allow_null=True)
#     hcomment = serializers.CharField(required=False)
#     # hbook = serializers.PrimaryKeyRelatedField(read_only=True)
#     hbook = serializers.StringRelatedField()
#
#     # hbook_id = serializers.IntegerField()
#
#     def create(self, validated_data):
#         return HeroInfo.objects.create(**validated_data)
#
#     def update(self, instance, validated_data):
#         """更新，instance为要更新的对象实例"""
#         instance.hname = validated_data.get('hname', instance.hname)
#         instance.hgender = validated_data.get('hgender', instance.hgender)
#         instance.hcomment = validated_data.get('hcomment', instance.hcomment)
#         instance.hbook = validated_data.get('hbook', instance.hbook)
#         instance.is_delete = validated_data.get('is_delete', instance.is_delete)
#         instance.save()
#         return instance


# 继承ListModelMixin 实现按关键词查询的功能
class QueryListModelMixin(ListModelMixin):
    def list(self, request, *args, **kwargs):
        keyword = request.query_params.get('keyword')
        queryset = self.get_queryset()
        if keyword:
            # http://127.0.0.1:8000/books?keyword=江湖
            queryset = queryset.filter(btitle__contains=keyword)

        # http://127.0.0.1:8000/books
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)


class MyModelViewSet(mixins.CreateModelMixin,
                   mixins.RetrieveModelMixin,
                   mixins.UpdateModelMixin,
                   mixins.DestroyModelMixin,
                   QueryListModelMixin,
                   GenericViewSet):
    """
    A viewset that provides default `create()`, `retrieve()`, `update()`,
    `partial_update()`, `destroy()` and `list()` actions.
    """
    pass
