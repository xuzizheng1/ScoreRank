"""
app URL Configuration
"""
from pprint import pprint

from django.conf.urls import url
from rest_framework.routers import DefaultRouter, SimpleRouter

from . import views

urlpatterns = []

router = DefaultRouter()  # 可以处理视图的路由器
# DefaultRouter与SimpleRouter的区别是，DefaultRouter会多附带一个默认的API根视图，返回一个包含所有列表视图的超链接响应数据。
# router = SimpleRouter()

router.register(r'books', views.BookInfoViewSet, basename='my_book')  # 向路由器中注册图书视图集
# router.register(r'heros', views.HeroInfoViewSet, 'my_hero')  # 向路由器中注册英雄视图集

# 输出drf框架自动生成的url
pprint(router.urls)

urlpatterns += router.urls  # 将路由器中的所以路由信息追到到django的路由列表中
