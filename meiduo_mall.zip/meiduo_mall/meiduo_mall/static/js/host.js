// var host = 'http://127.0.0.1:8000';
var host = 'http://www.meiduo.site:8000';