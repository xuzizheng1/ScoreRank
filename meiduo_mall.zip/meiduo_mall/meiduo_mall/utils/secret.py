from django.conf import settings
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer


class SecretOauth(object):
    def __init__(self):
        # 根据 签名(secret_key) 创建序列化对象
        self.serializer = Serializer(secret_key=settings.SECRET_KEY, expires_in=24 * 15 * 60)

    # 1.加密
    def dumps(self, data):
        # 通过 dumps方法 加密数据
        result = self.serializer.dumps(data)
        # result是bytes类型转换成 str
        return result.decode()

    # 2.解密
    def loads(self, data):
        # 通过 loads方法 解密数据
        return self.serializer.loads(data)

# from itsdangerous import TimedJSONWebSignatureSerializer
#
# s = TimedJSONWebSignatureSerializer(secret_key='abc',expires_in=30)
#
# data_dict = {'openid':'F1084s'}
#
# result = s.dumps(data_dict)
# #
# # print(result.decode())
#
# print(type(s.loads(result)))
