import json
import pickle
import base64


class CookieSecret(object):
    # 加密
    @classmethod
    def dumps(cls, data):
        # 1.将数据装换成bytes
        data_bytes = pickle.dumps(data)
        # 2.将bytes使用base64序列化加密
        base64_bytes = base64.b64encode(data_bytes)
        # 3.将加密完毕的bytes以字符串类型输出
        base64_str = base64_bytes.decode()
        return base64_str

    # 解密
    @classmethod
    def loads(cls, data):
        # 1.将数据解密转成bytes
        base64_bytes = base64.b64decode(data)
        # 2.将bytes转回原来的python类型
        pickle_data = pickle.loads(base64_bytes)
        return pickle_data


if __name__ == '__main__':
    data_dict = {
        1: {
            2: {
                'count': 2,
                'selected': True
            }
        }
    }
    #  json 作用  将 json_str 和 python dict/list 进行互转
    # json ---dict==>json_str
    json_str = json.dumps(data_dict)

    # json_str ===> dict
    json_dict = json.loads(json_str)

    # pickle 作用 将 对象数据 和 bytes 进行互转 --转换完毕 原始数据类型不会发生改变
    # pickle ---dict对象---bytes
    pickele_bytes = pickle.dumps(data_dict)

    # pickle --- bytes====dict 对象
    pickle_obj = pickle.loads(pickele_bytes)

    # base64 作用 将 bytes 进行编解码 混淆
    base64_encode = base64.b64encode(pickele_bytes)

    # base64 解码
    # base64_decode = base64.b64decode(base64_encode)

    print(type(base64_encode))
    print(pickle.loads(base64_encode))
