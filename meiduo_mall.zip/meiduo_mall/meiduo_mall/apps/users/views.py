import json
import re
from pprint import pprint

from django import http
from django.contrib.auth import logout
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import HttpResponse, JsonResponse, HttpResponseForbidden
from django.shortcuts import render, redirect
from django.urls import reverse
from django.views import View
from django_redis import get_redis_connection

from apps.goods.models import SKU
from apps.users.models import User, Address
from apps.users.utils import generate_verify_email_url
from meiduo_mall.settings.dev import logger
from utils import constants
from utils.response_code import RETCODE
from utils.secret import SecretOauth


# 10.用户浏览记录
class HistoriesView(LoginRequiredMixin, View):
    def post(self, request):

        # 1.接收参数
        sku_id = json.loads(request.body.decode()).get('sku_id')

        # 2.校验参数 -- sku存不存在
        try:
            sku = SKU.objects.get(pk=sku_id)
        except SKU.DoesNotExist:
            return render(request, '404.html')

        # sku_id 前端参数
        # sku.id 从数据库读取出来的id --- 建议使用第二种

        # 3.链接redis的客户端
        client = get_redis_connection('history')
        save_key = 'history_%s' % request.user.id
        pipeline = client.pipeline()

        # 3.1先去重
        pipeline.lrem(save_key, 0, sku.id)
        # 3.2再存储
        pipeline.lpush(save_key, sku.id)
        # 3.3截取5个数据
        pipeline.ltrim(save_key, 0, 4)

        pipeline.execute()

        # 4.返回响应对象
        return http.JsonResponse({'code': 0, 'errmsg': "存储成功!"})

    def get(self, request):

        # 1.链接redis数据 库  查询 所有的 sku_id
        client = get_redis_connection('history')
        save_key = 'history_%s' % request.user.id
        sku_ids = client.lrange(save_key, 0, -1)

        # 通过 范围查询 获取 所有 符合条件的 sku--- 结果是没问题--但是顺序混乱了
        # skus = SKU.objects.filter(id__in=sku_ids)
        # sku_list = []
        # for sku in skus:
        #
        #     sku_list.append({
        #         'id': sku.id,
        #         'name': sku.name,
        #         'default_image_url': sku.default_image.url,
        #         'price': sku.price
        #
        #     })

        sku_list = []
        for sku_id in sku_ids:
            # 2.根据 sku_id 获取 对应的 sku对象
            sku = SKU.objects.get(pk=sku_id)
            # 3.装换前端 需要的数据格式
            sku_list.append({
                'id': sku.id,
                'name': sku.name,
                'default_image_url': sku.default_image.url,
                'price': sku.price

            })

        # pprint(sku_list)

        # 4.返回 JsonResponse
        return http.JsonResponse({'code': RETCODE.OK, 'errmsg': 'OK', 'skus': sku_list})


# 9.修改密码
class ChangePwdView(LoginRequiredMixin, View):
    def get(self, request):
        return render(request, 'user_center_pass.html')

    def post(self, request):
        # 1.接收参数
        old_pwd = request.POST.get('old_pwd')
        new_pwd = request.POST.get('new_pwd')
        new_cpwd = request.POST.get('new_cpwd')

        # 2.form json 判空 判正则
        #
        # 3.判断 两次密码 是否 一致
        if new_pwd != new_cpwd:
            return http.HttpResponseForbidden('两次密码不一致!')

        # 4.校验 原始密码是否正确-- check_passord()
        if not request.user.check_password(old_pwd):
            return http.HttpResponseForbidden('密码不正确!')

        # 5.修改 user.password值 --set_password()
        request.user.set_password(new_pwd)
        request.user.save()

        # 6.重定向到登录页
        return redirect(reverse("users:login"))


# 8.新增 收货地址
class AddressCreateView(LoginRequiredMixin, View):
    def post(self, request):
        # 判断当前用户 --增加的收货地址的个数 不能大于20
        # 第一种写法 : 站在 Address表的角度查数据
        count = Address.objects.filter(user=request.user, is_deleted=False).count()

        # 第二种写法 : 站在 User表的角度 查数据 1:n
        # count = request.user.addresses.filter(is_deleted=False).count()
        print(count)

        if count > constants.USER_ADDRESS_COUNTS_LIMIT:
            return http.JsonResponse({'code': 0, 'errmsg': "收货地址最多20个"})

        # 1.接收参数 ---json--request.body
        json_dict = json.loads(request.body.decode())
        receiver = json_dict.get('receiver')
        province_id = json_dict.get('province_id')
        city_id = json_dict.get('city_id')
        district_id = json_dict.get('district_id')
        place = json_dict.get('place')
        mobile = json_dict.get('mobile')
        tel = json_dict.get('tel')
        email = json_dict.get('email')

        # 2.校验参数--判空--判正则--

        # 3.新增 数据库数据--Address.objects.create()
        try:
            address = Address.objects.create(
                user_id=request.user.id,
                title=receiver,
                receiver=receiver,
                province_id=province_id,
                city_id=city_id,
                district_id=district_id,
                place=place,
                mobile=mobile,
                tel=tel,
                email=email
            )
        except Exception as e:
            logger.error(e)
            return http.JsonResponse({'code': 0, 'errmsg': '增加失败!'})

        # 如果当前用户没有默认收货地址, 赋值第一个添加的地址作为默认地址
        if request.user.default_address is None:
            request.user.default_address = address
            request.user.save()

        # 4.构建前端 需要的数据格式 {}
        address_dict = {
            "id": address.id,
            "title": address.title,
            "receiver": address.receiver,
            "province": address.province.name,
            "city": address.city.name,
            "district": address.district.name,
            "place": address.place,
            "mobile": address.mobile,
            "tel": address.tel,
            "email": address.email
        }
        # 5.返回响应
        return http.JsonResponse({'code': RETCODE.OK, 'errmsg': '增加成功!', "address": address_dict})


# 用户收货地址
class AddressView(LoginRequiredMixin, View):
    """用户收货地址"""

    def get(self, request):
        """提供收货地址界面"""
        user = request.user

        # 1.查询当前用户的所有没删除的地址
        addresses = Address.objects.filter(user=user, is_deleted=False)

        # 2.构建前端数据格式  [{}]
        address_list = []
        for address in addresses:
            address_list.append({
                "id": address.id,
                "title": address.title,
                "receiver": address.receiver,
                "province": address.province.name,
                "city": address.city.name,
                "district": address.district.name,
                "place": address.place,
                "mobile": address.mobile,
                "tel": address.tel,
                "email": address.email
            })

        context = {
            'default_address_id': user.default_address_id,
            'addresses': address_list,
        }
        return render(request, 'user_center_site.html', context=context)


# 8.邮箱激活
class EmailVerifyView(LoginRequiredMixin, View):
    def get(self, request):
        # 1.接收token- 查询参数--request.GET
        token = request.GET.get('token')

        if not token:
            return http.HttpResponseForbidden('token无效了!')
        # 2.解密
        token_dict = SecretOauth().loads(token)

        # 3.校验 user_id  email
        try:
            user = User.objects.get(id=token_dict['user_id'], email=token_dict['email'])
            # 4.激活 email_active = True
            user.email_active = True
            user.save()
        except Exception as e:
            return http.HttpResponseForbidden('token有误!')

        # 5.重定向到 用户中心页面
        return redirect(reverse('users:info'))


# 7.添加邮箱
class EmailView(LoginRequiredMixin, View):
    """添加邮箱"""

    def put(self, request):
        """实现添加邮箱逻辑"""
        # 接收参数
        json_str = request.body.decode()
        json_dict = json.loads(json_str)
        email = json_dict.get('email')

        # 校验参数
        if not re.match(r'^[a-z0-9][\w\.\-]*@[a-z0-9\-]+(\.[a-z]{2,5}){1,2}$', email):
            return http.HttpResponseForbidden('参数email有误')

        # 赋值email字段
        try:
            request.user.email = email
            request.user.save()
        except Exception as e:
            logger.error(e)
            return http.JsonResponse({'code': RETCODE.DBERR, 'errmsg': '添加邮箱失败'})

        # 异步发送邮件
        verify_url = generate_verify_email_url(request.user)
        from celery_tasks.email.tasks import send_verify_email
        send_verify_email.delay(email, verify_url)

        # 响应添加邮箱结果
        return http.JsonResponse({'code': RETCODE.OK, 'errmsg': '添加邮箱成功'})


# 6.用户中心显示
class InfoView(LoginRequiredMixin, View):
    def get(self, request):
        context = {
            'username': request.user.username,
            'mobile': request.user.mobile,
            'email': request.user.email,
            'email_active': request.user.email_active
        }
        # 前端渲染的方式：
        # 1. render() --->jinja2渲染-- 前后端不分离
        # 2. JsonResponse--vue渲染---前后端分离
        # 3. render() --> jinja2渲染 --> js变量 --> vue渲染
        return render(request, 'user_center_info.html', context)


# 5.退出
class LogOutView(View):
    def get(self, request):
        # 1.取出登录的本质是 清空session==request.session.flush()
        # 对应django自带的logout()
        logout(request)

        # 2.清空 cookie
        response = redirect(reverse('contents:index'))
        response.delete_cookie('username')

        return response


# 4.登录
class LoginView(View):
    """用户名登录"""

    def get(self, request):
        """
        提供登录界面
        :param request: 请求对象
        :return: 登录界面
        """
        return render(request, 'login.html')

    def post(self, request):
        """
        实现登录逻辑
        :param request: 请求对象
        :return: 登录结果
        """
        # 1.接收三个参数
        username = request.POST.get('username')
        password = request.POST.get('password')
        remembered = request.POST.get('remembered')

        # 2.校验参数
        if not all([username, password]):
            return HttpResponseForbidden('参数不齐全')
        # 2.1 用户名
        if not re.match(r'^[a-zA-Z0-9_-]{5,20}$', username):
            return HttpResponseForbidden('请输入5-20个字符的用户名')
        # 2.2 密码
        if not re.match(r'^[0-9A-Za-z]{1,20}$', password):
            return HttpResponseForbidden('请输入8-20位的密码')

        # 3.验证用户名和密码--django自带的认证
        from django.contrib.auth import authenticate, login
        # 认证成功返回用户对象，否则返回None
        user = authenticate(username=username, password=password)

        if user is None:
            return render(request, 'login.html', {'account_errmsg': '用户名或密码错误'})

        # 4.保持登录状态
        login(request, user)

        # 5.是否记住用户名
        if remembered != 'on':
            # 不记住用户名, 浏览器结束会话就过期
            request.session.set_expiry(0)
        else:
            # 记住用户名, 浏览器会话保持两周
            request.session.set_expiry(None)

        # 6.返回响应结果
        next_url = request.GET.get('next')
        if next_url:
            response = redirect(next_url)
        else:
            response = redirect(reverse('contents:index'))

        # 注册时用户名写入到cookie，有效期15天, 前端取出cookie后可以显示用户的登录状态
        # response.set_cookie('username', username, max_age=3600 * 24 * 15)
        response.set_cookie('username', user.username, max_age=3600 * 24 * 15)

        # 合并购物车
        """
        合并前：
        cookie:  macbook  1  3台
                iphone    16 1
        redis   macbook  1  1台
                iphone    4  1

        合并之后的:
        cookie:   空
        redis     macbook  3台
                  iphone   1
                  iphone   1
        """
        from apps.carts.utils import merge_cart_cookie_to_redis
        merge_cart_cookie_to_redis(request, response)

        # 5.重定向到首页
        return response


# 3。判断手机号是否已注册
class MobileCountView(View):
    """判断手机号是否已注册"""

    def get(self, request, mobile):
        """
        :param request: 请求对象
        :param mobile: 手机号
        :return: JSON
        """
        count = User.objects.filter(mobile=mobile).count()
        return http.JsonResponse({'code': RETCODE.OK, 'errmsg': 'OK', 'count': count})


# 2。判断用户名重复
class UsernameCountView(View):
    """
    判断用户名是否已存在
    url(r'^usernames/(?P<username>[a-zA-Z0-9_-]{5,20})/count/$', views.UsernameCountView.as_view()),
    """

    def get(self, request, username):
        """
        :param request: 请求对象
        :param username: 用户名
        :return: JSON
        """
        count = User.objects.filter(username=username).count()
        return http.JsonResponse({'code': RETCODE.OK, 'errmsg': 'OK', 'count': count})


# 1. 注册
class RegisterView(View):
    def get(self, request):
        # return HttpResponse('register')
        return render(request, 'register.html')

    def post(self, request):

        # 接收参数
        username = request.POST.get('username')
        password = request.POST.get('password')
        password2 = request.POST.get('password2')
        mobile = request.POST.get('mobile')
        allow = request.POST.get('allow')

        # 校验参数
        # 判断参数是否齐全
        if not all([username, password, password2, mobile, allow]):
            return http.HttpResponseForbidden('缺少必传参数')
        # 判断用户名是否是5-20个字符
        if not re.match(r'^[a-zA-Z0-9_-]{5,20}$', username):
            return http.HttpResponseForbidden('请输入5-20个字符的用户名')
        # 判断密码是否是8-20个数字 测试用改为1-20位
        if not re.match(r'^[0-9A-Za-z]{1,20}$', password):
            return http.HttpResponseForbidden('请输入8-20位的密码')
        # 判断两次密码是否一致
        if password != password2:
            return http.HttpResponseForbidden('两次输入的密码不一致')
        # 判断手机号是否合法
        if not re.match(r'^1[3-9]\d{9}$', mobile):
            return http.HttpResponseForbidden('请输入正确的手机号码')
        # 判断是否勾选用户协议
        if allow != 'on':
            return http.HttpResponseForbidden('请勾选用户协议')

        # 短信验证
        # 1.接收 前端 用户 输入 短信验证码
        sms_code = request.POST.get('msg_code')
        # 2.从redis取出后台 短信验证码
        from django_redis import get_redis_connection
        redis_code_client = get_redis_connection('sms_code')
        redis_code = redis_code_client.get("sms_%s" % mobile)

        if redis_code is None:
            return render(request, 'register.html', {'sms_code_errmsg': '短信验证码过期 '})
            # return JsonResponse({'code': '4001', 'errmsg': '短信验证码已经过期'})

        if sms_code != redis_code.decode():
            return render(request, 'register.html', {'sms_code_errmsg': '输入短信验证码有误 '})
            # return JsonResponse({'code': '4001', 'errmsg': '输入短信验证码有误'})

        # 保存注册数据到mysql
        try:
            from apps.users.models import User
            # 这是使用默认的模型类 增加数据到数据库的操作，但密码没有加密，不安全，django校验时密码对不上，会报错
            # User.objects.create(username=username, password=password, mobile=mobile)

            # 这是使用django封装的 增加数据到数据库的操作
            user = User.objects.create_user(username=username, password=password, mobile=mobile)
        except Exception as e:
            # 保存异常信息到日志文件 logs/meiduo.log
            logger.error(e)
            # 前后端分离，返回json；前后端不分离，返回模板
            return render(request, 'register.html', {'register_message': '注册失败'})

        # 保持登录状态：session - request.session['key']=value
        from django.contrib.auth import login
        login(request, user)

        # 响应注册结果
        response = redirect(reverse('contents:index'))

        # 注册时用户名写入到cookie，有效期15天, 前端取出cookie后可以显示用户的登录状态
        response.set_cookie('username', user.username, max_age=3600 * 24 * 15)

        return response
