from pprint import pprint

from django.shortcuts import render
from django.views import View

from apps.contents.models import ContentCategory
from .utils import get_categories


class IndexView(View):
    """首页广告"""

    def get(self, request):
        """
        提供首页广告界面
        分析首页商品频道分类数据结构：
        {
            "1":
            {
                "channels":[
                    {"id":1, "name":"手机", "url":"http://shouji.jd.com/"},
                    {"id":2, "name":"相机", "url":"http://www.itcast.cn/"}
                ],
                "sub_cats":[
                    {
                        "id":38,
                        "name":"手机通讯",
                        "sub_cats":[
                            {"id":115, "name":"手机"},
                            {"id":116, "name":"游戏手机"}
                        ]
                    },
                    {
                        "id":39,
                        "name":"手机配件",
                        "sub_cats":[
                            {"id":119, "name":"手机壳"},
                            {"id":120, "name":"贴膜"}
                        ]
                    }
                ]
            },
            "2":
            {
                "channels":[],
                "sub_cats":[]
            }
        }
        """
        # 使用封装的方法，获取 商品分类的数据
        categories = get_categories()

        # 广告数据
        contents = {}
        content_categories = ContentCategory.objects.all()
        for cat in content_categories:
            contents[cat.key] = cat.content_set.filter(status=True).order_by('sequence')

        context = {
            'categories': categories,
            'contents': contents,
        }

        # 运行服务器，访问首页，查看控制台输出结果
        # pprint(categories)
        # pprint(contents)

        # 前后端不分离--jinja2模板渲染---后台程序员写的
        return render(request, 'index.html', context)
