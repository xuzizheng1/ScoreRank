import json
from pprint import pprint

from django import http
from django.http import JsonResponse
from django.shortcuts import render
from django.views import View
from django_redis import get_redis_connection

from apps.goods.models import SKU
from utils.cookiesecret import CookieSecret
from utils.response_code import RETCODE


# 购物车 增删改查
class CartsView(View):
    """购物车管理"""

    # 购物车 添加商品
    def post(self, request):
        """添加购物车"""
        # 接收参数
        json_dict = json.loads(request.body.decode())
        sku_id = json_dict.get('sku_id')
        count = json_dict.get('count')
        selected = json_dict.get('selected', True)

        # 判断参数是否齐全
        if not all([sku_id, count]):
            return http.HttpResponseForbidden('缺少必传参数')
        # 判断sku_id是否存在
        try:
            SKU.objects.get(id=sku_id)
        except SKU.DoesNotExist:
            return http.HttpResponseForbidden('商品不存在')
        # 判断count是否为数字
        try:
            count = int(count)
        except Exception:
            return http.HttpResponseForbidden('参数count有误')
        # 判断selected是否为bool值
        if selected:
            if not isinstance(selected, bool):
                return http.HttpResponseForbidden('参数selected有误')

        # 判断用户是否登录
        user = request.user
        if user.is_authenticated:
            # 3.1 用户已登录 使用redis存储
            carts_redis_client = get_redis_connection('carts')

            # 3.2 获取以前数据库的数据
            client_data = carts_redis_client.hgetall(user.id)

            # 如果商品已经存在就更新数据
            if str(sku_id).encode() in client_data:
                # 根据sku_id 取出商品
                child_dict = json.loads(client_data[str(sku_id).encode()].decode())
                #  个数累加
                child_dict['count'] += count
                # 更新数据
                carts_redis_client.hset(user.id, sku_id, json.dumps(child_dict))

            else:
                # 如果商品已经不存在--直接增加商品数据
                carts_redis_client.hset(user.id, sku_id, json.dumps({'count': count, 'selected': selected}))

            return JsonResponse({'code': RETCODE.OK, 'errmsg': '添加购物车成功'})
        else:
            # 用户未登录，操作cookie购物车
            cart_str = request.COOKIES.get('carts')
            # 如果用户操作过cookie购物车
            if cart_str:
                # 解密出明文
                cart_dict = CookieSecret.loads(cart_str)
            else:  # 用户从没有操作过cookie购物车
                cart_dict = {}

            # 判断要加入购物车的商品是否已经在购物车中,如有相同商品，累加求和，反之，直接赋值
            if sku_id in cart_dict:
                # 累加求和
                origin_count = cart_dict[sku_id]['count']
                count += origin_count
            cart_dict[sku_id] = {
                'count': count,
                'selected': selected
            }
            # 转成密文
            cookie_cart_str = CookieSecret.dumps(cart_dict)

            # 创建响应对象
            response = JsonResponse({'code': RETCODE.OK, 'errmsg': '添加购物车成功'})
            # 响应结果并将购物车数据写入到cookie
            response.set_cookie('carts', cookie_cart_str, max_age=24 * 30 * 3600)
            return response

    # 购物车 查询商品
    def get(self, request):
        """展示购物车"""
        user = request.user
        if user.is_authenticated:
            # 用户已登录，查询redis购物车
            carts_redis_client = get_redis_connection('carts')
            sku_dict_bytes = carts_redis_client.hgetall(user.id)
            # print(sku_dict_bytes)  # {b'1': b'{"count": 3, "selected": true}', b'5': b'{"count": 2, "selected": true}'}

            # sku_dict = dict()
            # for sku_id_bytes, count_selected_bytes in sku_dict_bytes.items():
            #     sku_id = int(sku_id_bytes.decode())
            #     count_selected = json.loads(count_selected_bytes.decode())
            #     sku_dict[sku_id] = count_selected
            # print(sku_dict)

            sku_dict = {int(sku_id_bytes.decode()): json.loads(count_selected_bytes.decode()) for
                        sku_id_bytes, count_selected_bytes in sku_dict_bytes.items()}
            # print(sku_dict)  # {1: {'count': 3, 'selected': True}, 5: {'count': 2, 'selected': True}}

        else:
            # 用户未登录，查询cookies购物车
            sku_str = request.COOKIES.get('carts')
            if sku_str:
                sku_dict = CookieSecret.loads(sku_str)
            else:
                sku_dict = dict()
            # print(sku_dict)  # {1: {'count': 2, 'selected': True}, 8: {'count': 5, 'selected': True}}

        sku_ids = sku_dict.keys()
        skus = SKU.objects.filter(id__in=sku_ids)
        cart_skus = list()
        for sku in skus:
            cart_skus.append({
                'id': sku.id,
                'name': sku.name,
                'count': sku_dict.get(sku.id).get('count'),
                'selected': str(sku_dict.get(sku.id).get('selected')),  # 将True，转'True'，方便json解析
                'default_image_url': sku.default_image.url,
                'price': str(sku.price),  # 从Decimal('10.2')中取出'10.2'，方便json解析
                'amount': str(sku.price * sku_dict.get(sku.id).get('count')),
            })

        context = {'cart_skus': cart_skus, }

        return render(request, 'cart.html', context)

    # 购物车 修改商品
    def put(self, request):
        # 接收参数
        json_dict = json.loads(request.body.decode())
        sku_id = json_dict.get('sku_id')
        count = json_dict.get('count')
        selected = json_dict.get('selected', True)

        # 校验参数
        # 1.判断参数是否齐全
        if not all([sku_id, count]):
            return http.HttpResponseForbidden('缺少必传参数')
        # 2.判断sku_id是否存在
        try:
            sku = SKU.objects.get(pk=sku_id)
        except SKU.DoesNotExist:
            return http.HttpResponseNotFound('商品sku_id不存在')
        # 3.判断count是否为数字
        try:
            count = int(count)
        except Exception:
            return http.HttpResponseForbidden('参数count有误')
        # 4.判断selected是否为bool值
        if selected:
            if not isinstance(selected, bool):
                return http.HttpResponseForbidden('参数selected有误')

        # 判断是否登录
        user = request.user
        # 存入cookie时使用
        cookie_cart_str = ''
        # 接收的新数据
        new_data = {'count': count, 'selected': selected}
        if user.is_authenticated:
            # 用户已登录 - redis
            # 1.链接 redis
            carts_redis_client = get_redis_connection('carts')
            carts_redis_client.hset(user.id, sku_id, json.dumps(new_data))

            # 输出测试
            # print(carts_redis_client.hgetall(user.id))

        else:
            # 用户未登录 - cookie
            cart_str = request.COOKIES.get('carts')
            cart_dict = CookieSecret.loads(cart_str) if cart_str else dict()
            cart_dict[sku.id] = new_data
            cookie_cart_str = CookieSecret.dumps(cart_dict)

            # 输出测试
            # print(cart_dict)

        # 构建前端的数据
        cart_sku = {
            'id': sku_id,
            'count': count,
            'selected': selected,
            'name': sku.name,
            'default_image_url': sku.default_image.url,
            'price': sku.price,
            'amount': sku.price * count,
        }

        response = JsonResponse({'code': RETCODE.OK, 'errmsg': '修改购物车成功', 'cart_sku': cart_sku})
        if not user.is_authenticated:
            # 响应结果并将购物车数据写入到cookie
            response.set_cookie('carts', cookie_cart_str, max_age=24 * 30 * 3600)
        return response

    # 购物车 删除商品
    def delete(self, request):
        # 接收参数
        sku_id = json.loads(request.body.decode()).get('sku_id')

        # 校验参数
        if not sku_id:
            return http.HttpResponseForbidden('参数不全')
        try:
            sku = SKU.objects.get(pk=sku_id)
        except SKU.DoesNotExist():
            return http.HttpResponseForbidden('对应的商品不存在')

        user = request.user
        cart_dict = dict()
        # 判断用户是否登录
        if user.is_authenticated:
            # 用户登录，redis
            # 1.链接 redis
            carts_redis_client = get_redis_connection('carts')
            carts_redis_client.hdel(user.id, sku.id)

            # 输出测试
            pprint(carts_redis_client.hgetall(user.id))

        else:
            # 用户未登录 - cookie
            cart_str = request.COOKIES.get('carts')
            if cart_str:
                # 转成明文
                cart_dict = CookieSecret.loads(cart_str)
            else:
                cart_dict = dict()

            # 输出测试
            # pprint(cart_dict)

        response = JsonResponse({'code': RETCODE.OK, 'errmsg': '删除购物车成功'})

        if sku_id in cart_dict:
            # 删除数据
            del cart_dict[sku_id]
            # 将字典转成密文
            cookie_cart_str = CookieSecret.dumps(cart_dict)
            # 响应结果并将购物车数据写入到cookie
            response.set_cookie('carts', cookie_cart_str, max_age=24 * 30 * 3600)

            # 输出测试
            # pprint(cart_dict)

        return response


# 购物车 全选商品
class CartAllSelectView(View):
    def put(self, request):
        # 接收参数
        selected = json.loads(request.body.decode()).get('selected')

        # 校验参数
        if selected:
            if not isinstance(selected, bool):
                return http.HttpResponseForbidden('参数selected有误')

        # 判断用户是否登录
        user = request.user
        if user.is_authenticated:
            # 用户已登录，操作redis购物车
            carts_redis_client = get_redis_connection('carts')
            redis_cart = carts_redis_client.hgetall(user.id)
            # print(redis_cart)  # {b'1': b'{"count": 2, "selected": true}', b'6': b'{"count": 3, "selected": true}'}

            # 将字典中的bytes转为str 此思路不正确
            # cart_dict={k.decode():v.decode() for k,v in redis_cart.items()}
            # print(cart_dict)

            # 加入管道，减少redis交互次数
            all_select_pipeline = carts_redis_client.pipeline()

            # 遍历所有 购物车数据 --修改 selected 属性 hset
            for key, value in redis_cart.items():
                sku_id = int(key.decode())
                carts_dict = json.loads(value.decode())

                # 修改所有商品的 选中状态
                carts_dict['selected'] = selected
                # 将redis语句放入管道
                all_select_pipeline.hset(user.id, sku_id, json.dumps(carts_dict))
            # 用管道一次执行所有redis语句
            all_select_pipeline.execute()

            # 打印测试
            # print(carts_redis_client.hgetall(user.id))

            return JsonResponse({'code': RETCODE.OK, 'errmsg': '全选购物车成功'})
        else:
            # 用户未登录，操作cookie购物车
            carts_str = request.COOKIES.get('carts')
            response = JsonResponse({'code': RETCODE.OK, 'errmsg': 'select all success'})
            if carts_str:
                carts_dict = CookieSecret.loads(carts_str)

                # 输出测试
                # print(carts_dict)

                for v in carts_dict.values():
                    v['selected'] = selected

                # 输出测试
                # print(carts_dict)

                cookie_cart = CookieSecret.dumps(carts_dict)
                response.set_cookie('carts', cookie_cart, 24 * 30 * 3600)
            return response


# 简单购物车 展示
class CartsSimpleView(View):
    def get(self, request):

        user = request.user

        if user.is_authenticated:
            # redis
            client = get_redis_connection('carts')
            redis_carts = client.hgetall(user.id)
            # 字典推导式
            cart_dict = {}
            for k, v in redis_carts.items():
                sku_id = int(k.decode())
                sku_dict = json.loads(v.decode())
                cart_dict[sku_id] = sku_dict

        else:
            # cookie
            cookie_str = request.COOKIES.get('carts')

            if cookie_str:
                cart_dict = CookieSecret.loads(cookie_str)
            else:
                cart_dict = {}

        # 根据sku_id 查询 sku 的数据
        cart_skus = []
        sku_ids = cart_dict.keys()
        for sku_id in sku_ids:
            sku = SKU.objects.get(pk=sku_id)
            cart_skus.append({
                'id': sku.id,
                'name': sku.name,
                'count': cart_dict.get(sku.id).get('count'),
                'default_image_url': sku.default_image.url
            })

        # 返回结果
        return http.JsonResponse({'code': 0, 'errmsg': '查询成功!', 'cart_skus': cart_skus})
