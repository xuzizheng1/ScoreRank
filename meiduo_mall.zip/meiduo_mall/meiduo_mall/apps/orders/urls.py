"""
app URL Configuration
"""
from django.conf.urls import url
from . import views

urlpatterns = [
    # get展示订单  post提交订单
    url(r'^orders/settlement/$', views.OrderSettlementView.as_view()),

    # 提交成功 页面 展示 orders/success/
    url(r'^orders/success/$', views.OrderSuccessView.as_view()),
]
