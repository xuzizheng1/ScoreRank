import json
import time
from datetime import datetime
from decimal import Decimal

from django import http
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import render
from django.views import View
from django_redis import get_redis_connection

from apps.goods.models import SKU
from apps.orders.models import OrderInfo, OrderGoods
from apps.users.models import Address
from utils.response_code import RETCODE


class OrderSettlementView(LoginRequiredMixin, View):
    """结算订单"""

    # 展示 订单页
    def get(self, request):
        """提供订单结算页面"""
        # 获取登录用户
        user = request.user

        # 1.查询地址
        try:
            addresses = Address.objects.filter(user=user, is_deleted=False)
        except:
            #  如果地址为空，渲染模板时会判断，并跳转到地址编辑页面
            addresses = None

        # 2.查询选中商品
        redis_client = get_redis_connection('carts')
        carts_data = redis_client.hgetall(user.id)
        # 转换格式
        carts_dict = {}
        for key, value in carts_data.items():
            sku_id = int(key.decode())
            sku_dict = json.loads(value.decode())
            if sku_dict['selected']:
                carts_dict[sku_id] = sku_dict

        # 3.计算金额 +邮费
        total_count = 0
        total_amount = Decimal(0.00)

        skus = SKU.objects.filter(id__in=carts_dict.keys())

        for sku in skus:
            sku.count = carts_dict[sku.id].get('count')
            sku.amount = sku.count * sku.price
            # 计算总数量和总金额
            total_count += sku.count
            total_amount += sku.count * sku.price

        # 运费
        freight = Decimal('10.00')

        # 4.构建前端显示的数据
        context = {
            'addresses': addresses,
            'skus': skus,
            'total_count': total_count,
            'total_amount': total_amount,
            'freight': freight,
            'payment_amount': total_amount + freight,
            'default_address_id': user.default_address_id
        }
        return render(request, 'place_order.html', context)

    # 提交订单
    def post(self, request):
        # 接收参数
        json_dict = json.loads(request.body.decode())
        address_id = json_dict.get('address_id')
        pay_method = int(json_dict.get('pay_method'))

        # 校验参数
        if not all([address_id, pay_method]):
            return http.HttpResponseForbidden('缺少必传参数')
            # 判断address_id是否合法
        try:
            address = Address.objects.get(pk=address_id)
        except Exception:
            return http.HttpResponseForbidden('参数address_id错误')
        # 判断pay_method是否合法
        if pay_method not in [v for v in OrderInfo.PAY_METHODS_ENUM.values()]:
            return http.HttpResponseForbidden('参数pay_method错误')

        # 获取用户
        user = request.user

        # 生成订单编号
        order_id = datetime.now().strftime('%Y%m%d%H%M%S') + ('%09d' % user.id)

        # --------with语句atomic()实现事务--------
        from django.db import transaction
        with transaction.atomic():

            # --------事物保存点savepoint()--------
            save_id = transaction.savepoint()
            try:
                # 保存订单信息到OrderInfo
                order = OrderInfo.objects.create(
                    order_id=order_id,
                    user=user,
                    address=address,
                    total_count=0,
                    total_amount=Decimal('0'),
                    freight=Decimal('10'),
                    pay_method=pay_method,
                    status=OrderInfo.ORDER_STATUS_ENUM['UNPAID'] if pay_method == OrderInfo.PAY_METHODS_ENUM[
                        'ALIPAY'] else
                    OrderInfo.ORDER_STATUS_ENUM['UNSEND'],
                )

                # 取 购物车的选中商品
                redis_client = get_redis_connection('carts')
                cart_data = redis_client.hgetall(user.id)
                # print(cart_data)
                selected_dict = dict()
                for k, v in cart_data.items():
                    sku_id = int(k.decode())
                    sku_dict = json.loads(v.decode())
                    if sku_dict['selected']:
                        selected_dict[sku_id] = sku_dict

                # 遍历 选中商品
                sku_ids = selected_dict.keys()
                # print(type(sku_ids))  # <class 'dict_keys'>

                for sku_id in sku_ids:
                    # 资源抢夺失败后，模拟库存充足时，重复下单，直到成功
                    while True:
                        sku = SKU.objects.get(pk=sku_id)

                        # 获取原始库存
                        origin_stock = sku.stock

                        cart_count = selected_dict.get(sku_id).get('count')
                        # 判断库存 ;  购买个数 大于> sku的库存stock
                        if cart_count > sku.stock:
                            # --------事物回滚--------
                            transaction.savepoint_rollback(save_id)

                            return http.JsonResponse({'code': RETCODE.STOCKERR, 'errmsg': '{}-库存不足!'.format(sku.name)})

                        # 加延迟 10s中---模拟资源抢夺 测试 并发下单
                        # time.sleep(10)

                        # 使用乐观锁 更新库存量
                        new_stock = origin_stock - cart_count
                        # sku销量增加
                        new_sales = sku.sales + cart_count
                        result = SKU.objects.filter(id=sku_id, stock=origin_stock).update(stock=new_stock,
                                                                                          sales=new_sales)

                        # 如果下单失败,库存足够则继续下单,直到下单成功或者库存不足
                        if result == 0:
                            continue

                        # spu  销量增加
                        sku.spu.sales += cart_count
                        sku.spu.save()

                        # 订单商品表 数据添加
                        OrderGoods.objects.create(
                            order=order,
                            sku=sku,
                            count=cart_count,
                            price=sku.price,
                        )

                        # 计算总数量，总金额
                        order.total_count += cart_count
                        order.total_amount += sku.price * cart_count

                        # 下单成功 或失败跳出
                        break

                # 订单添加邮费，保存订单信息到数据库
                order.total_amount += order.freight
                order.save()

            except:

                # --------事物回滚savepoint_rollback(save_id)--------
                transaction.savepoint_rollback(save_id)

                return http.JsonResponse({'code': RETCODE.OK, 'errmsg': '下单失败'})

                # --------提交事物savepoint_commit(save_id)--------
            transaction.savepoint_commit(save_id)

        # 删除购物车中的结算商品
        redis_client.hdel(user.id, *selected_dict)

        # 返回响应对象
        return http.JsonResponse({'code': 0, 'errmsg': '下单成功', 'order_id': order.order_id})


class OrderSuccessView(LoginRequiredMixin, View):
    def get(self, request):
        # 接收参数
        order_id = request.GET.get('order_id')

        # 校验订单
        try:
            order = OrderInfo.objects.get(order_id=order_id)
        except:
            return http.HttpResponseNotFound('订单不存在!')

        context = {
            'order_id': order.order_id,
            'payment_amount': order.total_amount,
            'pay_method': order.pay_method
        }

        return render(request, 'order_success.html', context)
