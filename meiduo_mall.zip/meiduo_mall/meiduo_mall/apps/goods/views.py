from pprint import pprint

from django import http
from django.core.paginator import Paginator, EmptyPage
from django.http import HttpResponseNotFound, HttpResponseServerError, JsonResponse
from django.shortcuts import render
from django.views import View

from apps.contents.utils import get_categories
from apps.goods.models import GoodsCategory, SKU
from apps.goods.utils import get_breadcrumb
from utils import constants
from utils.response_code import RETCODE


# 商品列表页
class ListView(View):
    def get(self, request, category_id, page_num):
        """
        # 列表页 list/115/1/?sort=排序方式
        url(r'^list/(?P<category_id>\d+)/(?P<page_num>\d+)/$', views.ListView.as_view()),
        :param category_id:  三级分类ID
        :param page_num:  当前第几页
        """
        try:
            cat3 = GoodsCategory.objects.get(pk=category_id)
        except GoodsCategory.DoesNotExist:
            return http.HttpResponseForbidden('商品不存在!')

        # 1. 获取 商品 分类数据
        categories = get_categories()

        # 2.面包屑组件的功能
        breadcrumbs = get_breadcrumb(cat3)

        # 3. 排序 --获取 所有 SKU的值
        # 前端传入的 sort 值  和  数据库的 字段 不对应 , 所以需要代码转换
        sort = request.GET.get('sort')

        # 按照排序规则查询该分类商品SKU信息
        if sort == 'price':
            # 按照价格由低到高
            order_field = 'price'
        elif sort == 'hot':
            # 按照销量由高到低
            order_field = '-sales'
        else:
            # 'price'和'sales'以外的所有排序方式都归为'default'
            order_field = 'create_time'
        # 对传入的category_id对应的三级分类下的所有sku排序
        skus = SKU.objects.filter(category=cat3, is_launched=True).order_by(order_field)

        # 创建分页器：每页N条记录
        paginator = Paginator(skus, constants.GOODS_LIST_LIMIT)
        # 获取每页商品数据
        try:
            page_skus = paginator.page(page_num)
        except EmptyPage:
            # 如果page_num不正确，默认给用户404
            return http.HttpResponseNotFound('empty page')
        # 获取列表页总页数
        total_page = paginator.num_pages

        # 上下文
        context = {
            'categories': categories,  # 频道分类
            'breadcrumbs': breadcrumbs,  # 面包屑导航
            'sort': sort,  # 排序字段
            'category': cat3,  # 第三级分类
            'page_skus': page_skus,  # 分页后数据
            'total_page': total_page,  # 总页数
            'page_num': page_num,  # 当前页码
        }

        # 打印测试
        # pprint(categories)
        # pprint(breadcrumbs)
        # pprint(skus)

        return render(request, 'list.html', context)


# 商品排行数据
class HotView(View):
    def get(self, request, category_id):
        """
        # 热销商品排行 url    category_id -- 第三级分类
        url(r'^hot/(?P<category_id>\d+)/$', views.HotView.as_view()),

        # 返回的数据格式：
        {
            "code":"0",
            "errmsg":"OK",
            "hot_skus":[
                {
                    "id":6,
                    "default_image_url":"http://image.meiduo.site:8888/group1/M00/00/02/CtM3BVrRbI2ARekNAAFZsBqChgk3141998",
                    "name":"Apple iPhone 8 Plus (A1864) 256GB 深空灰色 移动联通电信4G手机",
                    "price":"7988.00"
                },
                {
                    "id":14,
                    "default_image_url":"http://image.meiduo.site:8888/group1/M00/00/02/CtM3BVrRdMSAaDUtAAVslh9vkK04466364",
                    "name":"华为 HUAWEI P10 Plus 6GB+128GB 玫瑰金 移动联通电信4G手机 双卡双待",
                    "price":"3788.00"
                }
            ]
        }
        """
        # 根据销量倒序
        try:
            skus = SKU.objects.filter(category_id=category_id, is_launched=True).order_by('-sales')[:2]
        except:
            return http.HttpResponseForbidden('商品不存在!')

        # 序列化
        hot_skus = []
        for sku in skus:
            hot_skus.append({
                'id': sku.id,
                'default_image_url': sku.default_image.url,
                'name': sku.name,
                'price': sku.price
            })

        # pprint(hot_skus)

        return http.JsonResponse({'code': RETCODE.OK, 'errmsg': 'OK', 'hot_skus': hot_skus})


# 商品详情页
class DetailView(View):
    def get(self, request, sku_id):
        """提供商品详情页"""
        # 获取当前sku的信息
        try:
            sku = SKU.objects.get(id=sku_id)
        except SKU.DoesNotExist:
            return render(request, '404.html')

        # 查询商品频道分类
        categories = get_categories()
        # 查询面包屑导航
        breadcrumb = get_breadcrumb(sku.category)

        # 构建当前商品的规格键
        sku_specs = sku.specs.order_by('spec_id')
        sku_key = []
        for spec in sku_specs:
            sku_key.append(spec.option.id)
        # 获取当前商品的所有SKU
        skus = sku.spu.sku_set.all()
        # 构建不同规格参数（选项）的sku字典
        spec_sku_map = {}
        for s in skus:
            # 获取sku的规格参数
            s_specs = s.specs.order_by('spec_id')
            # 用于形成规格参数-sku字典的键
            key = []
            for spec in s_specs:
                key.append(spec.option.id)
            # 向规格参数-sku字典添加记录
            spec_sku_map[tuple(key)] = s.id
        # 获取当前商品的规格信息
        goods_specs = sku.spu.specs.order_by('id')
        # 若当前sku的规格信息不完整，则不再继续
        if len(sku_key) < len(goods_specs):
            return
        for index, spec in enumerate(goods_specs):
            # 复制当前sku的规格键
            key = sku_key[:]
            # 该规格的选项
            spec_options = spec.options.all()
            for option in spec_options:
                # 在规格参数sku字典中查找符合当前规格的sku
                key[index] = option.id
                option.sku_id = spec_sku_map.get(tuple(key))
            spec.spec_options = spec_options

        # 渲染页面
        context = {
            'categories': categories,
            'breadcrumb': breadcrumb,
            'sku': sku,
            'specs': goods_specs,
        }
        return render(request, 'detail.html', context)


# 第三级分类商品的访问量
class DetailVisitView(View):
    """
    #  统计 分类的访问量 detail/visit/(?P<category_id>\d+)/
    url(r'^detail/visit/(?P<category_id>\d+)/$', views.GoodsVisitView.as_view()),
    """

    def post(self, request, category_id):
        try:
            # 1.获取当前商品
            category = GoodsCategory.objects.get(id=category_id)
        except GoodsCategory.DoesNotExist:
            return HttpResponseNotFound('缺少必传参数')

        # 2.查询日期数据
        from datetime import date
        # 获取当天日期
        today_date = date.today()

        from .models import GoodsVisitCount
        try:
            # 3.如果有当天商品分类的数据  就累加数量
            goods_visit_object = category.goodsvisitcount_set.get(date=today_date)
        except:
            # 4. 没有, 就新建之后在增加
            goods_visit_object = GoodsVisitCount()

        try:
            goods_visit_object.count += 1
            goods_visit_object.category = category
            goods_visit_object.save()
        except Exception as e:
            return HttpResponseServerError('新增失败')

        return JsonResponse({'code': RETCODE.OK, 'errmsg': 'OK'})
