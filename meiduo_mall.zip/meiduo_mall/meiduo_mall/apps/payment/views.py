import os
from decimal import Decimal

from alipay import AliPay
from django import http
from django.conf import settings
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import render
from django.views import View

from apps.orders.models import OrderInfo
from apps.payment.models import Payment
from utils.response_code import RETCODE


# 返回支付宝链接，订单支付功能
class PaymentView(LoginRequiredMixin, View):
    def get(self, request, order_id):
        # url  payment/(?P<order_id>\d+)/
        # 路径参数 order_id 类型：int
        # 查询要支付的订单
        user = request.user
        try:
            order = OrderInfo.objects.get(order_id=order_id, user=user, status=OrderInfo.ORDER_STATUS_ENUM['UNPAID'])
        except OrderInfo.DoesNotExist:
            return http.HttpResponseForbidden('订单信息有误')

        # 创建支付宝支付对象 校验 参数的 真伪
        alipay = AliPay(
            appid=settings.ALIPAY_APPID,
            app_notify_url=None,  # 默认回调url
            # 美多的 私钥路径
            app_private_key_path=os.path.join(settings.BASE_DIR, 'apps/payment/keys/app_private_key.pem'),
            # alipay的 公钥路径
            alipay_public_key_path=os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                                'keys/alipay_public_key.pem'),
            sign_type="RSA2",
            debug=settings.ALIPAY_DEBUG
        )

        # 生成登录支付宝连接
        order_string = alipay.api_alipay_trade_page_pay(
            out_trade_no=order_id,
            total_amount=str(order.total_amount),
            subject="美多商城%s" % order_id,
            return_url=settings.ALIPAY_RETURN_URL,
        )

        # 响应登录支付宝连接
        # 真实环境电脑网站支付网关：https://openapi.alipay.com/gateway.do? + order_string
        # 沙箱环境电脑网站支付网关：https://openapi.alipaydev.com/gateway.do? + order_string
        alipay_url = settings.ALIPAY_URL + "?" + order_string
        return http.JsonResponse({'code': RETCODE.OK, 'errmsg': 'OK', 'alipay_url': alipay_url})


# 支付成功，支付宝返回数据给美多
class AliPaySuccessView(LoginRequiredMixin, View):
    """
    url: 使用#注释的参数暂不需要
        http://www.meiduo.site:8000/payment/status/?
        # charset=utf-8
        out_trade_no=20200220041202000000016  # 商品订单号
        # method=alipay.trade.page.pay.return
        total_amount=6509.00  # 需要跟数据库数据比对校验
        sign=Iu2IzqDnLeoJtZiiXWEJ7VXX%2FnzfQV%2BTaGx0FgchjTW7WfapX4JgRN4Ta8jK93DEHtz9ODtaLfQloboHad0W9NPVsavWpxTtUDeZxIVi4wwYUEqAoLEwcE%2B1JlHHloZHZe21fI1qjAATyIuzqB%2FKEQzZAW49CrjMmDbjpzdwuDvo6t6CIRIB7QPOdSOQCJRuMR4Vbk3OlK0c3uHi28R00oLkjS7deOkA6BHH0yOremIwrtSjD4dGVkaaA7nehShUsg6Wa2g%2BN3513wu%2F92rqJ6NNILdJpR5DZFVQHu08q3B9CG%2FIDsuAiTULZicTGABNk3R5Fd5lQeXn%2F3R29xbu%2Bw%3D%3D  # 签名 校验用
        trade_no=2020022022001477351000051697  # 支付宝交易流水号
        # auth_app_id=2016102100730785
        # version=1.0
        # app_id=2016102100730785
        # sign_type=RSA2
        # seller_id=2088102180492591
        # timestamp=2020-02-20+12%3A13%3A45
    """

    def get(self, request):
        # 获取前端传入的请求参数
        query_dict = request.GET
        data = query_dict.dict()
        # 获取并从请求参数中剔除signature
        signature = data.pop('sign')

        # 创建支付宝支付对象
        alipay = AliPay(
            appid=settings.ALIPAY_APPID,
            app_notify_url=None,
            app_private_key_path=os.path.join(os.path.dirname(os.path.abspath(__file__)), "keys/app_private_key.pem"),
            alipay_public_key_path=os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                                "keys/alipay_public_key.pem"),
            sign_type="RSA2",
            debug=settings.ALIPAY_DEBUG
        )
        # 校验这个重定向是否是alipay重定向过来的
        success = alipay.verify(data, signature)
        if success:
            # 读取order_id
            order_id = data.get('out_trade_no')
            # 读取url中的total_amount
            total_amount = Decimal(data.get('total_amount'))
            # 获取数据库中的total_amount
            db_total_amount = OrderInfo.objects.get(pk=order_id).total_amount
            # print(type(total_amount))
            # print(type(db_total_amount))
            if total_amount != db_total_amount:
                return http.HttpResponseForbidden('不合法的交易金额')
            # 读取支付宝流水号
            trade_id = data.get('trade_no')
            # 保存Payment模型类数据
            Payment.objects.create(
                order_id=order_id,
                trade_id=trade_id
            )

            # 修改订单状态为待评价
            OrderInfo.objects.filter(order_id=order_id, status=OrderInfo.ORDER_STATUS_ENUM['UNPAID']).update(
                status=OrderInfo.ORDER_STATUS_ENUM["UNCOMMENT"])

            # 响应trade_id
            context = {
                'trade_id': trade_id
            }
            return render(request, 'pay_success.html', context)
        else:
            # 订单支付失败，重定向到我的订单
            return http.HttpResponseForbidden('交易失败')
