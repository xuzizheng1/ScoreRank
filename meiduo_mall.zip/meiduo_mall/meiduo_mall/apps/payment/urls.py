"""
app URL Configuration
"""
from django.conf.urls import url
from . import views

urlpatterns = [
    # 支付宝支付 /payment/(?P<order_id>\d+)/
    url(r'^payment/(?P<order_id>\d+)/$', views.PaymentView.as_view()),

    # 支付成功后返回页面
    url(r'^payment/status/$', views.AliPaySuccessView.as_view()),
]
