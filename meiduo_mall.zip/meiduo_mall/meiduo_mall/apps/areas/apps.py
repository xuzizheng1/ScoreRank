from django.apps import AppConfig


class AreasConfig(AppConfig):
    name = 'apps.areas'
