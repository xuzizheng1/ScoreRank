from django.core.cache import cache
from django.http import JsonResponse
from django.shortcuts import render

# Create your views here.
from django.views import View

from apps.areas.models import Area
from utils.response_code import RETCODE

"""
    SQL
    省 select * from tb_areas where parent_id is NULL;
    市 select * from tb_areas where parent_id=130000;
    区 select * from tb_areas where parent_id=130100;

    ORM
    省 Area.objects.filter(parent_id__isnull=True)
    市 Area.objects.filter(parent_id=130000)
    区 Area.objects.filter(parent_id=130100)
"""


class AreaView(View):
    def get(self, request):

        # 1.area_id 查询参数
        area_id = request.GET.get('area_id')

        # 2.判断  area_id  如果 没有area_id-- 省份
        if not area_id:

            # 由于省市区查询比较频繁，将其存入django自带的缓存cache
            pro_list = cache.get('provinces')

            if not pro_list:
                provinces = Area.objects.filter(parent_id__isnull=True)

                # 转换前端 需要的数据格式  [{id:,name:}]
                # pro_list = []
                # for pro in provinces:
                #     pro_list.append({
                #         'id':pro.id,
                #         'name':pro.name
                #     })
                pro_list = [{"id": pro.id, 'name': pro.name} for pro in provinces]

                # 存入cache缓存
                cache.set('provinces', pro_list, 3600)

            return JsonResponse({'code': RETCODE.OK, 'errmsg': 'OK', 'province_list': pro_list})

        # 有area_id --市 县
        else:
            # 由于省市区查询比较频繁，将其存入django自带的缓存cache
            sub_data = cache.get('sub_%s' % area_id)

            if not sub_data:
                # cities = Area.objects.filter(parent_id=area_id)

                # 省-->市-->县---1: n
                parent = Area.objects.get(id=area_id)
                cities = parent.subs.all()

                # 测试cache是否存储成功
                print('市，区，数据库查询')

                # 县-->市-->省--n:1
                # "id":cities[0].parent.id,
                # "parent":cities[0].parent.name,
                # cities = Area.objects.filter(parent_id=area_id)

                subs = []
                for city in cities:
                    subs.append({
                        'id': city.id,
                        'name': city.name
                    })

                sub_data = {
                    "id": parent.id,
                    "parent": parent.name,
                    "subs": subs
                }

                # 将市，区信息存入cache
                cache.set('sub_%s' % area_id, sub_data, 3600)

            # return JsonResponse({'code': RETCODE.OK, 'errmsg': 'OK', 'sub_data': {'subs': subs}})
            return JsonResponse({'code': RETCODE.OK, 'errmsg': 'OK', 'sub_data': sub_data})
