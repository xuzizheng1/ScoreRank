"""
app URL Configuration
"""
from django.conf.urls import url
from . import views

urlpatterns = [
    # 查询省市区数据
    url(r'^areas/$', views.AreaView.as_view()),

]
