"""
app URL Configuration
"""
from django.conf.urls import url
from . import views

urlpatterns = [
    # 显示找回密码页面
    url(r'^find_password/$', views.FindPasswordView.as_view()),

    # 找回密码第一步： 输入用户名和图形验证码
    # http://www.meiduo.site:8000/accounts/laowang/sms/token/?image_code=FKCX&image_code_id=f708d49d-eb41-4823-8caf-2943dcc8c6cd
    url(r'^accounts/(?P<username>[a-zA-Z0-9_-]{5,20})/sms/token/$', views.FirstView.as_view()),

    # 找回密码第二步(1)： 发送短信验证码
    url(r'^find_password_sms_codes/(?P<mobile>1[3-9]\d{9})/$', views.FindPasswordSendSmsCodeView.as_view()),

    # 找回密码第二步(2)： 提交手机号和短信验证码 验证身份
    url(r'^accounts/(?P<mobile>[a-zA-Z0-9_-]{5,20})/password/token/$', views.SecondView.as_view()),

    # 找回密码第三步： 提交修改后的新密码
    url(r'^users/(?P<user_id>\d+)/new_password/$', views.UserNewPasswordView.as_view()),

]
