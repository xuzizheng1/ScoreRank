from django.apps import AppConfig


class FindpasswordConfig(AppConfig):
    name = 'apps.findpassword'
