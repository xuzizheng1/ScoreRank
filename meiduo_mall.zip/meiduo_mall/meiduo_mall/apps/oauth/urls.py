"""
app URL Configuration
"""
from django.conf.urls import url
from . import views

urlpatterns = [
    # 子路由---qq/login
    url(r'^qq/login/$', views.QQAuthURLView.as_view()),

    # 2.QQ登录成功之后 ---回调 地址  oauth_callback/
    url(r'^oauth_callback/$', views.QQAuthUserView.as_view()),

    # 显示微博登录页面
    url(r'^sina/login/$', views.WeiboLoginView.as_view()),

    # 微博回调的路由
    url(r'^sina_callback/$', views.WeiboCallbackView.as_view()),

    # 微博绑定用户 oauth/sina/user/
    url(r'^oauth/sina/user/$', views.WeiboBindUserView.as_view()),

]
