import json
import re

from QQLoginTool.QQtool import OAuthQQ
from django.conf import settings
from django.contrib.auth import login
from django.http import JsonResponse, HttpResponseForbidden, HttpResponse, HttpResponseServerError
from django.shortcuts import render, redirect
from django.urls import reverse
from django.views import View
from django_redis import get_redis_connection
from pymysql import DatabaseError

from utils.secret import SecretOauth
from .sinaweibopy3 import APIClient
from . import sinaweibopy3
from apps.oauth.models import OAuthQQUser, OAuthSinaUser
from apps.users.models import User
from utils.response_code import RETCODE


class QQAuthURLView(View):
    """提供QQ登录页面网址
    https://graph.qq.com/oauth2.0/authorize?response_type=code&client_id=xxx&redirect_uri=xxx&state=xxx
    """

    def get(self, request):
        # next表示从哪个页面进入到的登录页面，将来登录成功后，就自动回到那个页面
        next = request.GET.get('next')
        # 1.实例化 QQ 认证对象
        oauth = OAuthQQ(client_id=settings.QQ_CLIENT_ID, client_secret=settings.QQ_CLIENT_SECRET,
                        redirect_uri=settings.QQ_REDIRECT_URI, state=next)
        # 2。获取QQ登录页面网址
        login_url = oauth.get_qq_url()

        return JsonResponse({'code': RETCODE.OK, 'errmsg': 'OK', 'login_url': login_url})


# 是否绑定 openid
def is_bind_openid(openid, request):
    # 1.去数据查询 有没有 这个 openid
    try:
        auth_user = OAuthQQUser.objects.get(openid=openid)
    except Exception as e:
        # 2.对openid加密
        print(openid)
        from utils.secret import SecretOauth
        openid = SecretOauth().dumps({'openid': openid})
        print(openid)
        # 3.如果没有绑定---跳转到绑定页面
        return render(request, 'oauth_callback.html', context={'openid': openid})
    else:

        # 3.如果有 ---跳首页
        qq_user = auth_user.user
        # 保持登录状态
        login(request, qq_user)

        # 响应
        next = request.GET.get('state')
        response = redirect(next)

        # 设置cookie
        response.set_cookie('username', qq_user.username, max_age=24 * 30 * 3600)
        return response


class QQAuthUserView(View):
    """
        用户扫码登录的回调处理
        http://www.meiduo.site:8000/oauth_callback?code=5E6553674D903E118B59720C126C4B4D&state=None
    """

    def get(self, request):
        """Oauth2.0认证"""
        # 1.接收Authorization Code
        code = request.GET.get('code')
        if not code:
            return HttpResponseForbidden('缺少code')
        # 2.实例化 QQ 认证对象
        oauth = OAuthQQ(client_id=settings.QQ_CLIENT_ID, client_secret=settings.QQ_CLIENT_SECRET,
                        redirect_uri=settings.QQ_REDIRECT_URI)
        try:
            # 3.使用code向QQ服务器请求access_token
            access_token = oauth.get_access_token(code)

            # 4.使用access_token向QQ服务器请求openid
            openid = oauth.get_open_id(access_token)
            # print(openid)
            # 5.判断是否绑定 openid
            response = is_bind_openid(openid, request)
            return response
        except Exception as e:
            # settings.logger.error(e)
            return HttpResponseServerError('OAuth2.0认证失败')

    # 直接注册并绑定openid
    def post(self, request):
        """
        直接注册并绑定openid
        :param request:
        :return: 保持登录状态并重定向首页
        """

        # 1.解析参数
        mobile = request.POST.get('mobile')
        pwd = request.POST.get('password')
        sms_code = request.POST.get('sms_code')
        openid = request.POST.get('openid')

        # 校验openid
        if not openid:
            return HttpResponseForbidden('openid失效了')
        # 解密openid
        from utils.secret import SecretOauth
        openid = SecretOauth().loads(openid).get('openid')

        # 2.校验 判空--正则--图片--短信验证码
        # 判断参数是否齐全
        if not all([mobile, pwd, sms_code]):
            return HttpResponseForbidden('缺少必传参数')
        # 判断手机号是否合法
        if not re.match(r'^1[3-9]\d{9}$', mobile):
            return HttpResponseForbidden('请输入正确的手机号码')
        # 判断密码是否合格
        if not re.match(r'^[0-9A-Za-z]{8,20}$', pwd):
            return HttpResponseForbidden('请输入8-20位的密码')
        # 判断短信验证码是否一致
        redis_conn = get_redis_connection('sms_code')
        sms_code_server = redis_conn.get('sms_%s' % mobile)
        if sms_code_server is None:
            return render(request, 'oauth_callback.html', {'sms_code_errmsg': '无效的短信验证码'})
        if sms_code != sms_code_server.decode():
            return render(request, 'oauth_callback.html', {'sms_code_errmsg': '输入短信验证码有误'})

        # 3.校验mobile 是否存在
        try:
            user = User.objects.get(mobile=mobile)
            # 如果密码不正确
            if not user.check_password(pwd):
                return render(request, 'oauth_callback.html', {'errmsg': '用户或密码不正确'})
        except Exception as e:
            user = User.objects.create_user(username=mobile, password=pwd, mobile=mobile)

        # 4. 绑定openid
        try:
            oauth_user = OAuthQQUser.objects.create(user=user, openid=openid)
        except DatabaseError:
            return render(request, 'oauth_callback.html', {'qq_login_errmsg': 'QQ登录失败'})

        # 实现状态保持
        login(request, user)

        # 响应绑定结果
        next = request.GET.get('state')
        response = redirect(next)

        # 登录时用户名写入到cookie，有效期15天
        response.set_cookie('username', user.username, max_age=3600 * 24 * 15)

        return response


# 显示微博登录页面
class WeiboLoginView(View):
    def get(self, request):
        client = sinaweibopy3.APIClient(
            # app_key： app_key值
            app_key=settings.APP_KEY,
            # app_secret：app_secret 值
            app_secret=settings.APP_SECRET,
            # redirect_uri ： 回调地址
            redirect_uri=settings.REDIRECT_URL
        )

        login_url = client.get_authorize_url()

        return JsonResponse({'code': 0, 'errmsg': '微博登录网址', "login_url": login_url})


# 微博回调 如果用户没有绑定微博，跳转到绑定页面
class WeiboCallbackView(View):
    def get(self, request):
        client = APIClient(
            # app_key： app_key值
            app_key=settings.APP_KEY,
            # app_secret：app_secret 值
            app_secret=settings.APP_SECRET,
            # redirect_uri ： 回调地址
            redirect_uri=settings.REDIRECT_URL
        )

        # 1.获取回调传回来的 code
        code = request.GET.get('code')

        # 2.根据code值获取access_token和uid值
        result = client.request_access_token(code)
        # acces_token值在当前业务逻辑不需要使用，如果需要获取微博用户信息时会用到 ，但是当前业务逻辑只是完成绑定操作
        # access_token = result.access_token
        uid = result.uid

        # 3.判断 美多后台是否绑定了 uid; 如果绑定跳转到首页--没有绑定跳转到绑定页面(sina_callback.html)
        try:
            sina_user = OAuthSinaUser.objects.get(uid=uid)

        except OAuthSinaUser.DoesNotExist:
            # 不存在--绑定页面(sina_callback.html)--带着uid
            uid = SecretOauth().dumps({'uid': uid})
            return render(request, 'sina_callback.html', context={'uid': uid})

        user = sina_user.user

        # 保持登录状态
        login(request, user)

        # 设置首页用户名
        response = redirect(reverse('contents:index'))
        response.set_cookie('username', user.username, max_age=24 * 14 * 3600)
        # 重定向 首页

        return response


# 微博用户绑定
class WeiboBindUserView(View):
    def post(self, request):

        json_dict = json.loads(request.body.decode())

        mobile = json_dict.get('mobile')
        pwd = json_dict.get('password')
        sms_code = json_dict.get('sms_code')
        # 解密
        uid = SecretOauth().loads(json_dict.get('uid')).get('uid')

        if not uid:
            return JsonResponse({'status': 5004, 'errmsg': '无效的uid'})

        from django_redis import get_redis_connection
        redis_code_client = get_redis_connection('sms_code')
        redis_code = redis_code_client.get("sms_%s" % mobile)

        if redis_code is None:
            return JsonResponse({'status': 5001, 'errmsg': '无效的短信验证码'})

        if sms_code != redis_code.decode():
            return JsonResponse({'status': 5002, 'errmsg': '输入短信验证码有误'})

        # 保存注册数据
        try:
            user = User.objects.get(mobile=mobile)
        except User.DoesNotExist:
            # 用户不存在,新建用户
            user = User.objects.create_user(username=mobile, password=pwd, mobile=mobile)
        else:
            # 如果用户存在，检查用户密码
            if not user.check_password(pwd):
                return JsonResponse({'status': 5002, 'errmsg': '用户名或密码错误'})

                # 绑定用户
        OAuthSinaUser.objects.create(
            uid=uid,
            user=user
        )

        # 保持登录状态
        login(request, user)
        response = JsonResponse({'status': 5000, 'errmsg': '绑定成功!'})
        response.set_cookie('username', user.username, max_age=3600 * 24 * 15)

        return response
