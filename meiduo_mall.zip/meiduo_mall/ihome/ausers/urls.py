"""
app URL Configuration
"""
from django.conf.urls import url
from . import views

urlpatterns = [
    # 图形验证码
    url(r'^imagecode$', views.ImageCodeView.as_view()),

    # 短信验证码
    url(r'^smscode/$', views.SMSCodeView.as_view()),

    # 注册
    url(r'^user/register/$', views.RegisterView.as_view()),

    # 登录
    url(r'^login/$', views.LoginView.as_view()),

    # 获取登录状态
    url(r'^session/$', views.SessionView.as_view()),

    # 退出登录
    url(r'^logout/$', views.LogoutView.as_view()),

    # 获取用户信息 修改用户名
    url(r'^user/profile/$', views.UserInfoView.as_view()),

    # 上传用户头像
    url(r'^user/avatar/$', views.UserAvatarView.as_view()),

    # 实名信息 展示和修改
    url(r'^user/auth/$', views.AuthView.as_view()),

    # 我的房源
    url(r'^user/houses/$', views.MyHouse.as_view()),

]
