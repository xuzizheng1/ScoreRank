import json
import re

from django.contrib.auth import logout
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import HttpResponse, JsonResponse
from django.shortcuts import redirect
from django.urls import reverse
from django.views import View
from django_redis import get_redis_connection
from fdfs_client.client import Fdfs_client

from ausers.models import User
from ihome import settings
from libs.captcha.captcha import captcha
from libs.yuntongxun.sms import CCP
from utils.check_id_card import checkIdcard
from utils.constants import SMS_CODE_REDIS_EXPIRES, IMAGE_CODE_REDIS_EXPIRES
from utils.response_code import RET


# 图片验证码
class ImageCodeView(View):
    def get(self, request):
        # 接收参数
        cur = request.GET.get('cur')
        pre = request.GET.get('pre')

        # 省略校验参数

        # 生成图片验证码img_code和对应图片img
        img_code, img = captcha.generate_captcha()
        print('图片验证码：%s' % img_code)

        # 保存图形验证码img_code到redis
        redis_cli = get_redis_connection('verify_image_code')
        redis_cli.setex('img_%s' % cur, IMAGE_CODE_REDIS_EXPIRES, img_code)
        # 删除redis中的前一个图形验证码
        if pre:
            redis_cli.delete('img_%s' % pre)

        return HttpResponse(img, content_type='image/jpeg')


# 短信验证码
class SMSCodeView(View):
    """
    短信验证码
    url(r'^sms_codes/(?P<mobile>1[3-9]\d{9})/$', views.SMSCodeView.as_view()),
    """

    # sms_codes/(?P<mobile>1[3-9]\d{9})/
    def post(self, request):
        # 1.接收参数
        json_dict = json.loads(request.body.decode())
        mobile = json_dict.get('mobile')
        image_code = json_dict.get('image_code')
        uuid = json_dict.get('image_code_id')

        # 2.校验图形验证码 如果正确 发送验证码, 不正确 直接返回
        # 2.1 根据uuid 去redis数据库查询 图片验证码
        from django_redis import get_redis_connection
        image_redis_client = get_redis_connection('verify_image_code')
        redis_img_code = image_redis_client.get('img_%s' % uuid)
        # 判断服务器返回的验证
        if redis_img_code is None:
            return JsonResponse({'errno': RET.NODATA, 'errmsg': '图形验证码失效了'})
        # 如果有值 删除redis服务器上的图形验证码
        try:
            image_redis_client.delete('img_%s' % uuid)
        except Exception as e:
            settings.logger.error(e)
        # 2.2 和前端传过来的进行做对比
        # 千万注意: 在redis取出来的是 bytes 类型不能直接做对比 decode()
        # print(image_code.lower())
        # print(redis_img_code.decode().lower())
        if image_code.lower() != redis_img_code.decode().lower():
            return JsonResponse({'errno': RET.DATAERR, 'errmsg': '输入图形验证码有误'})

        # 3.生成短信验证码,redis-存储
        from random import randint
        sms_code = "%06d" % randint(0, 999999)
        sms_redis_cli = get_redis_connection('sms_code')
        sms_redis_cli.setex('sms_%s' % mobile, SMS_CODE_REDIS_EXPIRES, sms_code)
        print("短信验证码是:", sms_code)

        # 4.发送短信
        # 注意： 测试的短信模板编号为 1
        #                      自己手机号   验证码 过期时间  短信模板
        # CCP().send_template_sms(mobile, [sms_code, 5], 1)

        # 5.返回
        return JsonResponse({'errno': RET.OK, 'errmsg': '发送短信成功'})


# 注册
class RegisterView(View):
    def post(self, request):

        # 接收参数
        json_dict = json.loads(request.body.decode())
        mobile = json_dict.get('mobile')
        sms_code = json_dict.get('phonecode')
        password = json_dict.get('password')
        password2 = json_dict.get('password2')

        # 校验参数
        # 判断参数是否齐全
        if not all([mobile, sms_code, password, password2]):
            return JsonResponse({'errno': RET.PARAMERR, 'errmsg': '参数不全'})
        # 判断密码是否是8-20个数字 测试用改为4-20位
        if not re.match(r'^[0-9A-Za-z]{4,20}$', password):
            return JsonResponse({'errno': RET.PARAMERR, 'errmsg': '密码太短'})
        # 判断两次密码是否一致
        if password != password2:
            return JsonResponse({'errno': RET.PARAMERR, 'errmsg': '两次密码不一致'})
        # 判断手机号是否合法
        if not re.match(r'^1[3-9]\d{9}$', mobile):
            return JsonResponse({'errno': RET.PARAMERR, 'errmsg': '手机号不合法'})

        # 短信验证
        # 1.用户输入的短信验证码：sms_code
        # 2.取出redis中的 短信验证码 redis_code
        from django_redis import get_redis_connection
        redis_code_client = get_redis_connection('sms_code')
        redis_code = redis_code_client.get("sms_%s" % mobile)

        if redis_code is None:
            return JsonResponse({'errno': RET.PARAMERR, 'errmsg': '短信验证码过期'})

        # print(sms_code)
        # print(redis_code.decode())
        if sms_code != redis_code.decode():
            return JsonResponse({'errno': RET.PARAMERR, 'errmsg': '短信验证码错误'})

        # 保存注册数据到mysql
        try:
            from .models import User
            # 下面一行代码是使用默认的模型类 增加数据到数据库的操作,但密码没有加密,不安全,django校验时密码对不上,会报错
            # User.objects.create(username=username, password=password, mobile=mobile)

            # 这是使用django封装的 增加用户信息到数据库的操作
            user = User.objects.create_user(username=mobile, mobile=mobile, password=password)
        except Exception as e:
            # 保存异常信息到日志文件 logs/ihome.log
            settings.logger.error(e)
            # 前后端分离,返回json；前后端不分离,返回模板
            return JsonResponse({'errno': RET.DBERR, 'errmsg': '数据创建失败'})

        # 保持登录状态：session - request.session['key']=value
        from django.contrib.auth import login
        login(request, user)

        # 登录后,重定向到首页
        # response = redirect('/api/v1.0/imagecode')

        response = JsonResponse({'errno': RET.OK, 'errmsg': "注册成功"})

        # 注册时用户名写入到cookie,有效期15天, 前端取出cookie后可以显示用户的登录状态
        response.set_cookie('username', user.username, max_age=3600 * 24 * 15)

        return response


# 登录
class LoginView(View):

    def post(self, request):
        """
        实现登录逻辑
        :param request: 请求对象
        :return: 登录结果
        """
        # 1.接收参数
        json_dict = json.loads(request.body.decode())
        mobile = json_dict.get('mobile')
        password = json_dict.get('password')

        # 2.校验参数
        if not all([mobile, password]):
            return JsonResponse({'errno': RET.PARAMERR, 'errmsg': '参数不全'})
        # 2.1 手机号
        if not re.match(r'^1[3-9]\d{9}$', mobile):
            return JsonResponse({'errno': RET.PARAMERR, 'errmsg': '手机号格式不正确'})
        # 2.2 密码
        if not re.match(r'^[0-9A-Za-z]{4,20}$', password):
            return JsonResponse({'errno': RET.PARAMERR, 'errmsg': '密码不得少于4位,不得多于20位'})

        # 3.验证用户名和密码--django自带的认证
        from django.contrib.auth import authenticate, login
        # 认证成功返回用户对象,否则返回None
        user = authenticate(username=mobile, password=password)

        if user is None:
            return JsonResponse({'errno': RET.PARAMERR, 'errmsg': '用户名或密码错误'})

        # 4.保持登录状态
        login(request, user)

        # 5.是否记住用户名

        # 6.返回响应结果
        response = JsonResponse({'errno': RET.OK, 'errmsg': '成功'})

        # 注册时用户名写入到cookie,有效期15天, 前端取出cookie后可以显示用户的登录状态
        # response.set_cookie('username', username, max_age=3600 * 24 * 15)
        response.set_cookie('username', user.username, max_age=3600 * 24 * 15)

        # 5.重定向到首页
        return response


# 获取登录状态
class SessionView(View):
    def get(self, request):

        # user = request.user
        # if user.is_authenticated:
        #     return JsonResponse({"errno": RET.OK, "errmsg": "OK", "data": {"user_id": user.id, "name": user.username}})

        try:
            user = User.objects.get(pk=1)
        except:
            return JsonResponse({'errno': RET.SESSIONERR, 'errmsg': '未登录'})
        else:
            return JsonResponse({"errno": RET.OK, "errmsg": "OK", "data": {"user_id": user.id, "name": user.username}})


# 退出登录
# class LogoutView(LoginRequiredMixin, View):
class LogoutView(View):
    def delete(self, request):
        # 1.退出登录的本质是 清空session==request.session.flush()
        # 对应django自带的logout()
        # logout(request)

        # 2.清空 cookie
        # response = redirect(reverse('contents:index'))
        # response.delete_cookie('username')

        try:
            user = User.objects.get(pk=1)
        except:
            return JsonResponse({'errno': RET.SESSIONERR, 'errmsg': '未登录'})
        else:
            return JsonResponse({'errno': RET.OK, 'errmsg': "用户 %s 已退出" % user.username})


# 展示用户信息 修改用户名
# class UserInfoView(LoginRequiredMixin, View):
class UserInfoView(View):
    # 展示用户信息
    def get(self, request):
        """
        {
            "errno": "0",
            "errmsg": "OK",
            "data":
                {"name": "LQ",
                "avatar_url": "http://10.211.55.5:8888/group1/M00/00/02/CtM3BV0TOymAQ76QAAAxGsx647U5359315",
                "mobile": "17621766567" }
        }
        :param request:
        :return:
        """
        try:
            user = User.objects.get(id=1)
        except:
            return JsonResponse({'errno': RET.SESSIONERR, 'errmsg': '未登录'})
        else:
            data = {"name": user.username,
                    "avatar_url": user.avatar_url,
                    "mobile": user.mobile,
                    }
        return JsonResponse({'errno': RET.OK, 'errmsg': 'OK', "data": data})

    # 修改用户名
    def post(self, request):
        # 获取参数
        json_dict = json.loads(request.body.decode())
        user_name = json_dict.get('name')

        # 校验参数 省略一部分
        if not re.match(r'^\w{2,8}$', user_name):
            return JsonResponse({'errno': RET.PARAMERR, 'errmsg': '用户名长度 2-8'})

        # 修改用户名
        # user = request.user
        try:
            user = User.objects.get(id=1)
            user.username = user_name
            user.save()
        except:
            return JsonResponse({'errno': RET.DBERR, 'errmsg': '保存数据库失败'})

        # 返回
        return JsonResponse({'errno': RET.OK, 'errmsg': 'OK'})


# 上传用户头像
class UserAvatarView(View):
    def post(self, request):
        # 接收参数
        try:
            avatar_file = request.FILES.get('avatar')
            # print(avatar_file)
            # print(type(avatar_file))
        except:
            return JsonResponse({'errno': RET.DBERR, 'errmsg': '接收参数错误'})

        # 校验参数
        if not avatar_file:
            return JsonResponse({'errno': RET.PARAMERR, 'errmsg': '不能为空'})

        # 保存图片到fdfs
        try:
            client = Fdfs_client(settings.FDFS_CLIENT_CONF)
            result = client.upload_by_buffer(avatar_file.read())
        except Exception as e:
            settings.logger.error(e)
            return JsonResponse({'errno': RET.THIRDERR, 'errmsg': "上传图片错误"})

        # 拼接avatar_url
        avatar_url = settings.FDFS_BASE_URL + result.get('Remote file_id')

        # 保存到数据库
        user = User.objects.get(id=1)
        user.avatar_url = avatar_url
        user.save()

        # 返回
        return JsonResponse({'errno': RET.OK, 'errmsg': '成功', "data": {"avatar_url": user.avatar_url}})


# 实名信息 展示和修改
class AuthView(View):
    def get(self, request):
        """
        {
            "errno": 0,
            "errmsg": "success",
            "data": {'real_name':'xxx','id_card':'xx'}
        }
        """
        # 获取用户
        try:
            user = User.objects.get(id=1)
            real_name = user.real_name
            id_card = user.id_card
        except:
            return JsonResponse({'errno': RET.DBERR, 'errmsg': '数据库查询错误'})
        else:
            data = {'real_name': real_name, 'id_card': id_card}
            return JsonResponse({'errno': RET.OK, 'errmsg': 'success', 'data': data})

    def post(self, request):
        # 获取参数
        json_dict = json.loads(request.body.decode())
        real_name = json_dict.get('real_name')
        id_card = json_dict.get('id_card')

        # 校验参数 只校验身份证号
        if checkIdcard(id_card) != '验证通过!':
            return JsonResponse({'errno': RET.PARAMERR, 'errmsg': '身份证号有误'})

        # 修改数据
        try:
            user = User.objects.get(id=1)
            user.real_name = real_name
            user.id_card = id_card
            user.save()
        except:
            return JsonResponse({'errno': RET.DBERR, 'errmsg': '数据库查询错误'})
        else:
            return JsonResponse({'errno': RET.OK, 'errmsg': 'OK'})


# 我的房源
class MyHouse(View):
    def get(self, request):
        """
            {
                'data':[
                    {
                          'address':'房屋地址',
                          'area_name':'东城区',
                          'ctime':'2019-11-12',
                          'house_id':'1',
                          'img_url':'房屋图片地址',
                          'order_count':0,
                          'price':1000,
                          'room_count':1,
                          'title':'国贸CBD三里屯地铁阳光超赞大卧室',
                          'user_avatar':'用户图像地址',
                    },

                    {...},

                    {...},
                ],
                'errmsg':'OK',
                'errno':'0',
            }
        """

        try:
            # 获取房东
            user = User.objects.get(id=1)
            # 获取我的房源
            houses = user.house_set.all()
        except:
            return JsonResponse({'errno': RET.DBERR, 'errmsg': '获取我的房源失败'})

        # 拼接数据
        house_data = []
        for h in houses:
            house_data.append({
                'address': h.address,
                'area_name': h.area.name,
                'ctime': h.create_time.strftime("%Y-%m-%d"),
                'house_id': h.id,
                'img_url': h.index_image_url,
                'order_count': h.order_count,
                'price': h.price,
                'room_count': h.room_count,
                'title': h.title,
                'user_avatar': user.avatar_url,
            })

        return JsonResponse({'errno': RET.OK, 'errmsg': 'OK', 'data': house_data})
