from django.apps import AppConfig


class AusersConfig(AppConfig):
    name = 'ausers'
