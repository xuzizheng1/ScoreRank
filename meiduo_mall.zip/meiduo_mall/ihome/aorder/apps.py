from django.apps import AppConfig


class AorderConfig(AppConfig):
    name = 'aorder'
