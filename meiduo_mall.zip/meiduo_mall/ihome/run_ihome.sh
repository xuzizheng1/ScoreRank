#!/bin/bash

redis-server /etc/redis/redis.conf
echo '**************************************************************'
echo 'redis 已开启...'
echo '**************************************************************'

echo ''
echo ''

echo '**************************************************************'
echo 'http.server 已开启... 127.0.0.1:8080 访问'
echo '**************************************************************'
cd /Users/zheng/Desktop/shunyi31/ihome/zhome
python -m http.server 8080 --bind 127.0.0.1

echo ''
echo ''
