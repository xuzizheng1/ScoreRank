from django.apps import AppConfig


class AhouseConfig(AppConfig):
    name = 'ahouse'
