"""
app URL Configuration
"""
from django.conf.urls import url
from . import views

urlpatterns = [
    # 城区列表
    url(r'^areas/$', views.AreasView.as_view()),

    # 发布新房源
    url(r'^houses/$', views.HouseRelease.as_view()),

    # 上传房源图片
    url(r'^houses/(?P<house_id>\d+)/images/$', views.HouseImageView.as_view()),

    # 房源详情页面
    url(r'^houses/(?P<house_id>\d+)/$', views.HouseDetailView.as_view()),

    # 首页房源推荐
    url(r'^houses/index/$', views.HouseIndexView.as_view()),

    # 首页房源搜索
    url(r'^houses/search/$', views.HouseSearchView.as_view()),

]
