import json
from datetime import datetime
from pprint import pprint

from django.core.cache import cache
from django.core.paginator import Paginator
from django.http import JsonResponse
from django.views import View

from ahouse.utils import house_to_dict, check_price
from aorder.models import Order
from ausers.models import User
from ihome import settings
from ihome.settings import FDFS_CLIENT_CONF, FDFS_BASE_URL
from utils import constants
from utils.constants import HOME_PAGE_MAX_HOUSES
from .models import Area, House, Facility, HouseImage
from utils.response_code import RET

user = User.objects.get(id=1)


# 城区展示
class AreasView(View):
    def get(self, request):
        """
        {
            "errmsg": "OK",
            "errno": "0",
            "data": [
                {
                    "aid": 1,
                    "aname": "东城区"
                },
                {
                    "aid": 2,
                    "aname": "西城区"
                },
                {
                    "aid": 3,
                    "aname": "朝阳区"
                }
            ]
        }
        :param request:
        :return:
        """
        # 读取省份缓存数据
        areas_data = cache.get('areas')
        if not areas_data:
            # 查询城区数据
            try:
                areas = Area.objects.all()
            except:
                return JsonResponse({'errno': RET.PARAMERR, 'errmsg': '查询城区数据 错误'})
            # 储存市或区缓存数据
            areas_data = [{'aid': a.id, 'aname': a.name} for a in areas]
            cache.set('areas', areas_data, 3600)
        # pprint(areas_data)
        return JsonResponse({'errno': RET.OK, 'errmsg': 'OK', 'data': areas_data})


# 发布新房源
class HouseRelease(View):
    def post(self, request):
        """
        参数：
            title: "111"
            price: "1"
            area_id: "5"
            address: "1"
            room_count: "1"
            acreage: "1"
            unit: "1"
            capacity: "1"
            beds: "1"
            deposit: "1"
            min_days: "1"
            max_days: "1"
            facility: ["1", "3", "5"]
        """
        # 接收参数
        json_dict = json.loads(request.body.decode())
        title = json_dict.get('title')
        price = json_dict.get('price')
        area_id = json_dict.get('area_id')
        address = json_dict.get('address')
        room_count = json_dict.get('room_count')
        acreage = json_dict.get('acreage')
        unit = json_dict.get('unit')
        capacity = json_dict.get('capacity')
        beds = json_dict.get('beds')
        deposit = json_dict.get('deposit')
        min_days = json_dict.get('min_days')
        max_days = json_dict.get('max_days')
        facility = json_dict.get('facility')  # list

        # 校验参数 省略
        price = check_price(price)
        deposit = check_price(deposit)

        # 保存到数据库
        try:
            new_house = House.objects.create(
                user=user,
                area_id=area_id,
                title=title,
                price=price,
                address=address,
                room_count=room_count,
                acreage=acreage,
                unit=unit,  # 如几室几厅
                capacity=capacity,  # 房屋容纳的人数
                beds=beds,
                deposit=deposit,
                min_days=min_days,
                max_days=max_days,  # 0表示不限制
                # order_count  # 预计该房屋的订单数
                # index_image_url  # 房屋主图片的路径
                # facilities=facility,
            )
        except:
            return JsonResponse({'errno': RET.DBERR, 'errmsg': '保存房屋失败'})
        try:
            facilities = Facility.objects.filter(id__in=facility)
            # print(facilities)
            # print(type(facilities))
            new_house.facilities.add(*facilities)
            new_house.save()
        except:
            return JsonResponse({'errno': RET.DBERR, 'errmsg': '保存房屋失败'})

        house_id = new_house.id if new_house else None
        return JsonResponse({'errno': RET.OK, 'errmsg': '成功', 'data': {"house_id": house_id}})


# 上传房源图片
class HouseImageView(View):
    def post(self, request, house_id):
        """
        :param request:
        :param house_id:
        :return: {'errno': RET.OK, 'errmsg': "OK", 'data': {"url":上传的图片URL链接}}
        """

        # 接收参数
        # house_id = request.POST.get('house_id')
        img = request.FILES.get('house_image')

        # 校验参数 省略
        if not img:
            return JsonResponse({'errno': RET.PARAMERR, 'errmsg': '图片未上传'})
        try:
            house = House.objects.get(pk=house_id)
        except:
            return JsonResponse({'errno': RET.DBERR, 'errmsg': '房屋不存在'})

        # 保存图片到fdfs
        try:
            from fdfs_client.client import Fdfs_client
            client = Fdfs_client(FDFS_CLIENT_CONF)
            ret = client.upload_by_buffer(img.read())
        except:
            return JsonResponse({'errno': RET.DATAERR, 'errmsg': '图片保存失败'})

        img_url = FDFS_BASE_URL + ret.get('Remote file_id')

        # 保存到数据库
        try:
            HouseImage.objects.create(
                url=img_url,
                house_id=house_id
            )
        except:
            return JsonResponse({'errno': RET.DBERR, 'errmsg': '数据库错误'})

        if not house.index_image_url:
            try:
                house.index_image_url = img_url
                house.save()
            except:
                return JsonResponse({'errno': RET.DBERR, 'errmsg': '数据库错误'})

        return JsonResponse({'errno': RET.OK, 'errmsg': 'OK', 'data': {"url": img_url}})


# 房源详情页面
class HouseDetailView(View):
    def get(self, request, house_id):
        """
        "data": {

            "house": {
                "acreage": 5,
                "address": "我是地址",
                "beds": "5张床",
                "capacity": 5,
                "comments": [
                    {
                        "comment": "哎哟不错哟",
                        "ctime": "2017-11-14 11:17:07",
                        "user_name": "匿名用户"
                    }
                ],
                "deposit": 500,
                "facilities": [
                    1
                ],
                "hid": 4,
                "img_urls": [
                    "http://10.211.55.5:8888/group1/M00/00/02/CtM3BV0TJvuACmsFAAb3-me55444072188",
                    "xxxxxxx",
                    ......
                ],
                "max_days": 5,
                "min_days": 5,
                "price": 500,
                "room_count": 5,
                "title": "555",
                "unit": "5",
                "user_avatar":      "xxxx用户图片链接",
                "user_id": 1,
                "user_name": "哈哈哈哈哈哈"
            },

            "user_id": 1
        }
        """
        # 路径参数 house_id

        # 校验参数
        try:
            house = House.objects.get(pk=house_id)
        except:
            return JsonResponse({'errno': RET.DBERR, 'errmsg': '房屋不存在'})

        user_id = user.id if user.id else -1

        # 房屋信息
        house_dict = house_to_dict(house)

        # 拼接参数
        data = {
            "house": house_dict,
            "user_id": user_id,
        }

        # 返回数据
        return JsonResponse({'errno': RET.OK, 'errmsg': 'OK', 'data': data})


# 首页房源推荐
class HouseIndexView(View):
    def get(self, request):
        """
        'data':[
            {
                'house_id':4,
                'img_url':'xxx',
                'title':'xxx'
            },

            {...},

            .......
        ]
        """

        # 遍历房屋
        try:
            houses = House.objects.all().order_by('-order_count')
        except Exception as e:
            settings.logger.error(e)
            return JsonResponse({'errno': RET.DBERR, 'errmsg': '数据库错误'})

        # 限制展示的房屋数量
        limit_houses = houses[:HOME_PAGE_MAX_HOUSES] if houses.count() > HOME_PAGE_MAX_HOUSES else houses

        # 拼接参数
        data = []
        for house in limit_houses:
            data.append({
                'house_id': house.id,
                'img_url': house.index_image_url,
                'title': house.title,
            })

        # 返回数据
        return JsonResponse({'errno': RET.OK, 'errmsg': 'OK', 'data': data})


# 首页房源搜索
class HouseSearchView(View):
    def get(self, request):
        """
        查询参数：
            aid int 区域id

            sd string 开始日期

            ed string 结束时间

            sk string 排序方式
                1 booking(订单量),
                2 price - inc(低到高),
                3 price - des(高到低)
                4 new-最新上线

            p int 页数，不传默认为1

        返回数据：
        {
            'data':{
                    'houses': [ {xxx}, {xxx} ],
                    'total_page':2
            },
            'errmsg':'请求成功',
            'errno':'0'
        }
        """
        # 接收参数
        query_dict = request.GET
        area_id = query_dict.get('aid')
        sd = query_dict.get('sd')
        ed = query_dict.get('ed')
        sort_key = query_dict.get('sk', 'new')
        p = query_dict.get('p', '1')
        # print((aid, sd, ed, sk, p))
        # print((type(aid), type(sd), ed, type(sk), type(p)))

        try:
            page = int(p)
        except Exception as e:
            settings.logger.error(e)
            return JsonResponse({'errno': RET.PARAMERR, 'errmsg': "参数错误"})

            # 日期转换
        try:
            start_date = None
            end_date = None
            if sd:
                start_date = datetime.strptime(sd, '%Y-%m-%d')
            if ed:
                end_date = datetime.strptime(ed, '%Y-%m-%d')
            # 如果开始时间大于或者等于结束时间，就报错
            if start_date and end_date:
                assert start_date < end_date, Exception("开始时间大于结束时间")
        except Exception as e:
            settings.logger.error(e)
            return JsonResponse({'errno': RET.PARAMERR, 'errmsg': "参数错误"})

        filters = {}
        # 判断是否传入城区id
        if area_id:
            filters['area_id'] = area_id
        house_query = House.objects.filter(**filters)

        # 过滤已预订的房屋
        conflict_order = None
        try:
            if start_date and end_date:
                conflict_order = Order.objects.filter(begin_date__lte=end_date, end_date__gte=start_date)
            elif start_date:
                conflict_order = Order.objects.filter(end_date__gte=start_date)
            elif end_date:
                conflict_order = Order.objects.filter(begin_date__lte=end_date)
        except Exception as e:
            settings.logger.error(e)
            return JsonResponse({'errno': RET.DBERR, 'errmsg': "查询数据错误"})

        if conflict_order:
            # 取到冲突订单的房屋id
            conflict_house_id = [order.house_id for order in conflict_order]
            house_query = house_query.exclude(id__in=conflict_house_id)

        # 根据筛选条件进行排序
        if sort_key == "booking":
            # 订单量排序
            house_query = house_query.order_by('-order_count')
        elif sort_key == "price-inc":
            # 价格从低到高
            house_query = house_query.order_by('price')
        elif sort_key == "price-des":
            # 价格从高到低
            house_query = house_query.order_by('-price')
        else:
            # 创建时间排序
            house_query = house_query.order_by('create_time')

        # 获取分页器对象
        paginator = Paginator(house_query, constants.HOUSE_LIST_PAGE_CAPACITY)
        # 获取指定页房屋数据
        houses = paginator.page(page)
        # 获取列表页总页数
        total_page = paginator.num_pages

        # 将查询结果转成字符串
        houses_dict = []
        for house in houses:
            houses_dict.append({
                "house_id": house.id,
                "title": house.title,
                "price": house.price,
                "area_name": house.area.name,
                "img_url": house.index_image_url if house.index_image_url else "",
                "room_count": house.room_count,
                "order_count": house.order_count,
                "address": house.address,
                "user_avatar": user.avatar_url if user.avatar_url else "",
                "ctime": house.create_time.strftime("%Y-%m-%d")
            })

        response_data = {"total_page": total_page, "houses": houses_dict}
        return JsonResponse({'errno': RET.OK, 'errmsg': '请求成功', 'data': response_data})
